import type { Config } from 'jest';

const config: Config = {
  transform: {
    '^.+\\.(ts|tsx|mjs)$': 'ts-jest',
    '^.+\\.(js|jsx|cjs)$': 'babel-jest',
  },
  testEnvironment: 'jsdom',
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1'
  },
  setupFilesAfterEnv: ['<rootDir>/src/__tests__/setup.ts'],
  testPathIgnorePatterns: [
    '<rootDir>/node_modules/', 
    '<rootDir>/dist/', 
    '<rootDir>/src/__tests__/setup.ts'
  ],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node', 'mjs'],
  transformIgnorePatterns: ['<rootDir>/node_modules/(?!.*\\.mjs$)'],
};

export default config;