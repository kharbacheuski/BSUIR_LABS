type IconProps = {
    color?: string,
    width?: number | string
    height?: number | string
}

export const Logo = ({color = "black", width, height}: IconProps) => {

    return (
        <svg width={width} height={height} viewBox="0 0 192 166" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M55.1534 103L33.7045 30.2727H55.7216L65.6648 75.017H66.233L78.0227 30.2727H95.3523L107.142 75.1591H107.71L117.653 30.2727H139.67L118.222 103H99.3295L86.9716 62.375H86.4034L74.0455 103H55.1534Z" fill={color}/>
            <line x1="130.265" y1="34.2362" x2="182.265" y2="162.236" stroke={color} strokeWidth="20"/>
            <line x1="10.7385" y1="117.11" x2="9.99834" y2="0.0633888" stroke="#502FE5" strokeWidth="20"/>
        </svg>
    )
}


export const Circle = ({color = "#7756FE", width, height}: IconProps) => {
    return (
        <svg width={width} height={height} viewBox="0 0 1912 1998" fill="none" xmlns="http://www.w3.org/2000/svg">
            <ellipse cx="956" cy="999" rx="956" ry="999" fill={color}/>
        </svg>
    )
}

export const Rectangle = ({color = "#7756FE", width, height}: IconProps) => {

    return (
        <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="414" height="951" fill={color}/>
        </svg>
    )
}