import { Navigate, useRoutes } from "react-router-dom";
import Login, {AuthComponentType}  from '@/pages/auth/page';
import Wallet from '@/pages/wallet/page';
import Page404 from '@/pages/404';
import Payments from '@/pages/payments/page';
import Verification from '@/pages/verification/page';
import Statement from '@/pages/statement/page';
import Profile from "@/pages/profile/page";
import Blog from "@/pages/blog/page";
import Post from "@/pages/post/page";
import { useContext } from "react";
import { AuthContext } from "./components/providers/auth-provider";
import Onboarding from "./pages/onboarding/page";

export const ProtectedRoute = ({ isAuth, children }) => {
    if (!isAuth) {
        return <Navigate to="/auth/sign-in" />;
    }

    return children;
};

export const Element = () => {
    const {isAuth} = useContext(AuthContext)

    const routes = useRoutes([
        { path: "*", element: <ProtectedRoute isAuth={isAuth}><Navigate to="/404" /></ProtectedRoute> },
        { path: "/", element: <ProtectedRoute isAuth={isAuth}><Wallet /></ProtectedRoute> },
        { path: "/blog", element: <Blog /> },
        { path: "/blog/:slug", element: <Post /> },
        { path: "/profile", element: <ProtectedRoute isAuth={isAuth}><Profile /></ProtectedRoute> },
        { path: "/payments/:walletNumber?/", element: <ProtectedRoute isAuth={isAuth}><Payments /></ProtectedRoute> },
        { path: "/statement/", element: <ProtectedRoute isAuth={isAuth}><Statement /></ProtectedRoute> },
        { path: "/auth/sign-up", element: <Login type={AuthComponentType.Registration} /> },
        { path: "/auth/sign-in", element: <Login type={AuthComponentType.Login} /> },
        { path: "/onboarding/:questionNumber?", element: <Onboarding /> },
        { path: "/verification", element: <ProtectedRoute isAuth={isAuth}><Verification /></ProtectedRoute> },
        { path: "/404", element: <Page404 /> }
    ])

    return routes
}