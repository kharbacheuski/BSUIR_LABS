import ReactDOM from 'react-dom/client';
import Main from './Main';

const root = ReactDOM.createRoot(document.getElementById('cabinet') as HTMLElement);
root.render(<Main />);