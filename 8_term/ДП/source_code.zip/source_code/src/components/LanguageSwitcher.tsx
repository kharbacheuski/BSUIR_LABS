import { 
    MenuItem,
    Box,
    IconButton,
    Paper,
    ClickAwayListener
} from "@mui/material";
import { useContext, useState } from "react"
import React from "react"
import ReactCountryFlag from "react-country-flag"
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { LangContext, languages } from "./providers/lang-provider";

const overrideCodes = {
    "en": "gb",
}

const LanguageSwitcher: React.FC<{}> = ({}) => {
    const {language, setLanguage} = useContext(LangContext)

    const [isFlagsVisible, setIsFlagsVisible] = useState<boolean>(false)

    const handleChange = (lang: Language) => {
        setLanguage(lang)
        localStorage.setItem("lang", lang.code)
        setIsFlagsVisible(false)
    }


    const handleFlags = () => {
        setIsFlagsVisible(prev => !prev)
    }

    const onClickAway = () => {
        setIsFlagsVisible(false)
    }   

    return (
        <ClickAwayListener onClickAway={onClickAway}>
            <Box sx={{position: "relative", display: "flex", flexDirection: "column", zIndex: 4}}>
                <Box sx={{display: "flex", alignItems: "center", cursor: "pointer"}} onClick={handleFlags}>
                    <ReactCountryFlag svg style={{width: "20px", height: "20px"}} countryCode={(overrideCodes[language.code] || language.code).toUpperCase()} />
                    
                    <IconButton sx={{marginLeft: "5px", width: "30px", height: "30px"}} >
                        <KeyboardArrowUpIcon sx={{transform: isFlagsVisible ? "rotate(0deg)" : "rotate(180deg)", transition: "all .2s"}} />
                    </IconButton>
                </Box>

                {isFlagsVisible && <Paper 
                    sx={theme => ({
                        position: "absolute", 
                        top: "40px", 
                        right: "10px",
                        padding: "15px 10px", 
                        borderRadius: "10px", 
                        backgroundColor: theme.palette.background.paper,
                        boxShadow: "0 0 10px 0 rgba(0, 0, 0, 0.2)",
                    })}
                >
                    {languages?.map(item => <MenuItem onClick={() => handleChange(item)} key={item.code}>
                        <ReactCountryFlag key={item.code} svg style={{width: "20px", height: "20px", marginRight: "10px"}} countryCode={(overrideCodes[item.code] || item.code).toUpperCase()}/> {item.name}
                    </MenuItem>)}
                </Paper>}
            </Box>
        </ClickAwayListener>
    )
}

export default LanguageSwitcher