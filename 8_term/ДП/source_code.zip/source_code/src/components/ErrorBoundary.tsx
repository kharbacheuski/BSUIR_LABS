
import React from "react";
import { Box, Button, Typography } from "@mui/material";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";

type ErrorStateType = {
    error: string | null, 
    errorInfo: {
        componentStack: string
    } | null
}

type ErrorPropsType = {
    children: any
}

class ErrorBoundary extends React.Component <ErrorPropsType, ErrorStateType> {
    constructor(props) {
        super(props);

        this.state = { 
            error: null, 
            errorInfo: null 
        };
    }
    
    componentDidCatch(error, errorInfo) {
        this.setState({
            error: error,
            errorInfo: errorInfo
        })
    }
    
    render() {
        const {t} = useTranslation()

        if (this.state?.errorInfo) {
            return (
                <Box padding={"50px 25px"} marginTop={"50px"}>
                    <Typography variant="h4" sx={{marginBottom: "25px"}}>There was a problem on this page</Typography>
                    <details style={{ whiteSpace: 'pre-wrap' }}>
                        {this.state.error && this.state.error.toString()}
                        <br />
                        {this.state.errorInfo.componentStack}
                    </details>
                    <Link style={{textDecoration: "none"}} to="/">
                        <Button variant="contained" sx={{height: "50px", marginTop: "50px"}} onClick={() => setTimeout(() => window.location.reload(), 0)}>
                            {t("Home page")}
                        </Button>
                    </Link>
                </Box>
            );
        }
        
        return this.props.children;
    }  
}   

export default ErrorBoundary