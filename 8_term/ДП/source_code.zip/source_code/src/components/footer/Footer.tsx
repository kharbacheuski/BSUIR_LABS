import { Box, Container, Typography, useTheme } from "@mui/material";
import {Logo} from "../../../images/icons";
import Navigation from "../footer/Navigation";
import { AuthContext } from "@/components/providers/auth-provider";
import { useContext } from "react";

const Footer = () => {
    const theme = useTheme()
    const { isAuth } = useContext(AuthContext)

    return (
        isAuth && <Box component={"footer"} sx={(theme) => ({      
            backgroundColor: theme.palette.header,
            backdropFilter: "saturate(180%) blur(10px)",
        })} className="page_footer">
            <Container>
                <Box sx={{display: "flex", flexDirection: "column", gap: "20px", padding: "30px 20px"}}>    
                    <Logo width={60} height={60} color={theme.palette.text.primary}/>

                    <Navigation />

                    <Typography sx={{color: theme.palette.grey[500], marginTop: "20px"}} variant="caption">
                        (C) 2025 Горбачевский Кирилл и Горбачевский Максим. 
                        <br/>
                        Дипломное проектирование: "Платёжно-финансовая система" 
                        <br/>
                        БГУИР, ВМСиС
                    </Typography>
                </Box>
            </Container>
        </Box>
    )
}

export default Footer