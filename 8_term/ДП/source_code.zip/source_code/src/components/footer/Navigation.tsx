import { Box, useTheme } from "@mui/material";
import {  NavLink } from "react-router-dom";
import menu from "../header/menu.json"
import { useTranslation } from "react-i18next";

const Navigation = () => {
    const theme = useTheme()
    const {t} = useTranslation()

    return (
        <Box sx={{
            display:"flex",
            flexDirection:"row",
            gap: "30px",

            [theme.breakpoints.down('md')]: {
                flexDirection: "column",
            }
        }} className="footer_nav">        
            {menu.map(menuItem => (
                <NavLink
                    className="footer_nav-link"
                    key={menuItem.link}
                    to={menuItem.link}
                >
                    {t(menuItem.name)}
                </NavLink>  
            ))}
        </Box>
    )
}

export default Navigation