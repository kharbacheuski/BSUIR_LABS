import { Box, Button, IconButton, Modal, useMediaQuery, useTheme } from "@mui/material";
import { Fragment, useContext, useState } from "react";
import menu from "./menu.json"
import {Logo} from "../../../images/icons";
import ThemeSwitcher from "@/components/ThemeSwitcher";
import LogoutIcon from '@mui/icons-material/LoginOutlined';
import { AuthContext } from "@/components/providers/auth-provider";
import type { Theme } from '@mui/material/styles/createTheme';
import MenuIcon from '@mui/icons-material/Menu';
import Paper from '@mui/material/Paper';
import CloseIcon from '@mui/icons-material/Close';
import { NavLink } from "react-router-dom";
import "./styles.scss";
import { useTranslation } from "react-i18next";
import LanguageSwitcher from "../LanguageSwitcher";

const Navigation = () => {
    const theme = useTheme();
    const mdUp = useMediaQuery(theme.breakpoints.up('md'));
    
    const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
    const { isAuth, setIsAuth } = useContext(AuthContext);

    const handleMenu = (state: boolean = false) => {
        setIsMenuOpen(state);
    };

    const exitHandle = () => {
        handleMenu(false);
        localStorage.clear();
        setIsAuth(false);
    };

    const { t } = useTranslation();

    return (
        <Fragment>
            <Box className="header_logo">
                <NavLink to="/" style={{ display: "block" }}>
                    <Logo width={mdUp ? 40 : 60} height={mdUp ? 40 : 60} color={theme.palette.text.primary} />
                </NavLink>
            </Box>
            
            {mdUp && isAuth && (
                <Box sx={{
                    display: "flex",
                    flexDirection: "row",
                    gap: "30px",
                }} className="header_nav">
                    {menu.map(menuItem => (
                        <NavLink
                            className={({ isActive }) => isActive ? "header_nav-link active" : "header_nav-link"}
                            key={menuItem.link}
                            to={menuItem.link}
                            onClick={() => handleMenu(false)}
                        >
                            {t(menuItem.name)}
                        </NavLink>
                    ))}
                </Box>
            )}

            {!mdUp && (
                <IconButton className="header_burger" onClick={() => handleMenu(true)}>
                    <MenuIcon sx={{ width: 30, height: 30 }} />
                </IconButton>
            )}

            <Modal
                open={isMenuOpen}
                onClose={() => handleMenu(false)}
                className="header_mobile-nav"
            >
                <Paper
                    elevation={12}
                    sx={{
                        p: "50px 20px",
                        display: 'flex',
                        flexDirection: 'column',
                        gap: "20px",
                        height: "100vh",
                        backgroundImage: "none"
                    }}
                >
                    <IconButton sx={{
                        position: "absolute",
                        top: 20,
                        right: 20
                    }} onClick={() => handleMenu(false)}>
                        <CloseIcon />
                    </IconButton>
                    <Box sx={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "30px",
                    }}>
                        {menu.map(menuItem => (
                            <NavLink
                                className={({ isActive }) => isActive ? "header_nav-link active" : "header_nav-link"}
                                key={menuItem.link}
                                to={menuItem.link}
                                onClick={() => handleMenu(false)}
                            >
                                {t(menuItem.name)}
                            </NavLink>
                        ))}
                    </Box>

                    {isAuth && (
                        <Button sx={{ margin: "20px 0 0 0" }} variant="contained" onClick={exitHandle}>
                            {t("Logout")} <LogoutIcon sx={{
                                cursor: "pointer",
                                transition: "all .1s",
                                marginLeft: "5px",
                                "&:hover": {
                                    transform: "scale(1.1)"
                                }
                            }} />
                        </Button>
                    )}

                    <Box sx={{display: 'flex', gap: "20px", alignItems: "center"}}>
                        <ThemeSwitcher /> 
                        <LanguageSwitcher />
                    </Box>
                </Paper>
            </Modal>
        </Fragment>
    );
};

export default Navigation;