import { Box, useMediaQuery } from "@mui/material";
import { useContext } from "react";
import ThemeSwitcher from "@/components/ThemeSwitcher";
import LogoutIcon from '@mui/icons-material/LoginOutlined';
import { AuthContext } from "@/components/providers/auth-provider";
import type { Theme } from '@mui/material/styles/createTheme';
import Navigation from "./Navigation";
import { useNavigate } from "react-router-dom";
import LanguageSwitcher from "../LanguageSwitcher";

const Header = () => {
    const { isAuth, setIsAuth } = useContext(AuthContext)
    const navigate = useNavigate()
    
    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));

    const exitHandle = () => {
        localStorage.removeItem("token")
        navigate("/auth/sign-in")
        setIsAuth(false)
    }

    return (
        <Box component={"header"} sx={(theme) => ({
            width: "100%",
            padding: !mdUp ? "15px 20px" : "10px",
            display: "flex",                   
            justifyContent: "space-between",
            alignItems:"center",    
            backgroundColor: theme.palette.header,
            backdropFilter: "saturate(180%) blur(10px)",
            position: "sticky",
            top: 0,
            zIndex: 10,
        })} className="page_header header">
            <Navigation />

            {mdUp && <Box className="header_actions" sx={{display: "flex", flexDirection: "row", gap: "20px", alignItems: "center"}}>
                <ThemeSwitcher />
                <LanguageSwitcher />
                {isAuth && 
                    <LogoutIcon className="header_actions-logout" sx={{
                        cursor: "pointer",
                        transition: "all .1s",
                        
                        "&:hover": {
                            transform: "scale(1.1)"
                        }
                    }} onClick={exitHandle} />
                }
            </Box>}
        </Box>
    )
}

export default Header