import { Alert, AlertTitle, Box, IconButton, Typography } from "@mui/material";
import { useEffect } from "react";
import { useTimer } from 'react-timer-hook';
import CloseIcon from '@mui/icons-material/Close';
import { useTranslation } from "react-i18next";

export type AlertTypes = "warning" | "error" | "info" | "success";

export type AlertStateType = {
    isVisible: boolean;
    message: string;
    severity: AlertTypes;
    onCloseHandle?: () => void;
    autoCloseTime? : number
}

const AlertComponent: React.FC<{
    message: string;
    isVisible: boolean;
    onCloseHandle: () => void;
    type: AlertTypes;
    autoCloseTime?: number
}> = ({ message, isVisible, onCloseHandle, type, autoCloseTime = 3000}) => {
    const time = new Date();
    time.setMilliseconds(time.getMilliseconds() + autoCloseTime);

    const {
        seconds,
        pause,
        resume,
        restart,
    } = useTimer({ expiryTimestamp: time, autoStart: false, onExpire: onCloseHandle });

    useEffect(() => {
        isVisible && restart(time)
    }, [isVisible]);

    const {t} = useTranslation()

    return isVisible && (
        <Box sx={{ position: "fixed", zIndex: 3, bottom: "15px", left: "15px", width: "calc(100% - 30px)" }}>
            <Alert 
                onPointerEnter={pause} 
                onPointerLeave={resume} 
                severity={type}
                action={
                    <Box sx={{display: "flex", alignItems: "center"}}>
                        <IconButton
                            role="close-alert"
                            size="small"
                            onClick={onCloseHandle}
                        >
                            <CloseIcon fontSize="inherit" />
                        </IconButton>
                        <Typography color={type}>{seconds}s</Typography>
                    </Box>
                }
            >
                <AlertTitle>{t(type)}</AlertTitle>
                {t(message)}
            </Alert>
        </Box>
    );
};

export default AlertComponent;