import { Box } from "@mui/material"
import { FC } from "react"

export const TEMPLATE_COLORS = [
    {main: "#ffb4ff", text: "#000000"},
    {main: "#ff7b7b", text: "#000000"},
    {main: "#E3DCFF", text: "#000000"},
    {main: "#50d5d0", text: "#000000"},
    {main: "#8e638e", text: "#ffffff"},
    {main: "#ffc3c3", text: "#000000"},
    {main: "#7756FE", text: "#000000"},
    {main: "#0f0f0f", text: "#ffffff"},
]

export const getContrastColor = (color: string) => {
    return TEMPLATE_COLORS.find(tc => tc.main == color)?.text || "#ffffff"
}

const ColorSelect: FC<{value: string, setValue: React.Dispatch<React.SetStateAction<string>>}> = ({value, setValue}) => {
    return (
        <Box sx={{display: "flex", gap: 1, marginTop: "30px"}}>
            {TEMPLATE_COLORS.map(color => (
                <Box 
                    sx={{
                        width: 30, 
                        height: 30, 
                        borderRadius: "50%", 
                        backgroundColor: color.main, 
                        cursor: "pointer",

                        "&.active": {
                            transform: "scale(1.2)"
                        }
                    }} 
                    onClick={() => setValue(color.main)} 
                    key={color.main}
                    className={value == color.main ? "active" : ""}
                ></Box>
            ))}
        </Box>
    )
}

export default ColorSelect