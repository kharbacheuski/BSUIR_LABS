import { useState, useContext, type FC, Fragment, useEffect } from 'react';
import { useTheme, Box, Paper, useMediaQuery, Theme} from '@mui/material';
import { Modal }from '@mui/material';

const ModalWindow: FC<{
    isVisible: boolean; 
    handleClose: () => void,
    children
    styles?: any,
}> = ({isVisible, handleClose, children, styles}) => {
    const theme = useTheme();

    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));

    const style = {
        position: 'absolute' as 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: mdUp ? 600 : "100%",
        zIndex: 2,
        ...styles
    };

    const [error, setError] = useState<boolean>(false);

    const onClose = () => {
        setError(false);

        handleClose();
    }

    useEffect(() => {
        if(isVisible) {
            document.body.style.overflow = "hidden";
        }
        else {
            document.body.style.overflow = "auto";
        }
    }, [isVisible])

    return (<Fragment>
        <Modal
            sx={{
                ".MuiBackdrop-root": {
                    backgroundColor: theme.palette.mode === "dark" ? "rgba(0, 0, 0, 0.5)" : "rgba(255, 255, 255, 0.4)",
                    backdropFilter: "blur(7px)",
                }
            }}
            open={isVisible}
            onClose={onClose}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
        >
            <Box sx={style}>
                <Paper
                    elevation={12}
                    sx={theme => ({
                        p: "50px 20px",
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: "20px",
                        backgroundImage: "none",
                        backgroundColor: "transparent",
                        boxShadow: "none",
                    })}
                >
                    {children}
                </Paper>
            </Box>
        </Modal>
    </Fragment>)
};

export default ModalWindow