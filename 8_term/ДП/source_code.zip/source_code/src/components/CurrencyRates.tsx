import { Box, Theme, Typography, useMediaQuery } from "@mui/material"
import { methods } from "@/api/methods";
import { useQuery } from "@tanstack/react-query";

const CurrencyRates = () => {
    const {data: rates, isLoading} = useQuery({
        queryKey: ["rates"], 
        queryFn: async () => {
            const {data} = await methods.currency.getRates()

            return data
        },
    })
    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));

    return rates?.map((rate) => (
        <Box 
            className="card"
            sx={(theme) => ({
                backgroundColor: theme.palette.background.paper,
                width: "250px",
                padding: mdUp ? "10px 25px" : "10px 15px",
                borderRadius: "10px",

                ".rate": {
                    transition: "all .2s",
                },

                "&:hover": {
                    ".rate": {
                        transform: "scale(1.2)"
                    }
                }
            })}
            key={rate.currencyFromCode+rate.currencyToCode}
        >
            <Box sx={{
                display: "flex",
                justifyContent: "space-between",
            }}>
                <Typography>{rate.currencyFromCode}/{rate.currencyToCode}</Typography>
                <Typography className="rate" fontWeight={700}>{rate.rate}</Typography>
            </Box>
            
            <Typography variant="caption" sx={{marginTop: "5px"}}>{new Date(rate.date).toLocaleTimeString()}</Typography> 
        </Box>
    ))
}

export default CurrencyRates