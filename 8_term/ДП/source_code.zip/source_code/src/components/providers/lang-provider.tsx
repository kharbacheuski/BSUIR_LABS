import React, { useEffect, createContext, useState } from 'react';
import localizationInstance from "../../utilities/i18n";
import { I18nextProvider } from 'react-i18next';

type LangContextType = {
    language: Language,
    setLanguage: React.Dispatch<React.SetStateAction<Language>>
}

export const LangContext = createContext<LangContextType>({
    language: {
        name: "English",
        code: "en"
    },
    setLanguage: () => {}
})

export const languages = [
    {name: "English", code: "en"},
    {name: "Русский", code: "ru"}
]
 
function LangProvider({ children }) {
    const [language, setLanguage] = useState<Language>(languages.find(l => l.code === localStorage.getItem("lang")) || languages[0])

    useEffect(() => {
        localizationInstance.changeLanguage(language.code);
    }, [language])

    return (
        <I18nextProvider i18n={localizationInstance}>
            <LangContext.Provider value={{language, setLanguage}}>
                {children}
            </LangContext.Provider>
        </I18nextProvider>
    )
}

export default LangProvider