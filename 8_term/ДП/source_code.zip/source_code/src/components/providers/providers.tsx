import ThemeProvider from './theme-provider';
import AuthProvider from './auth-provider';
import { Suspense } from 'react';
import ErrorBoundary from '@/components/ErrorBoundary';
import Loading from "@/components/Loader"
import {
    QueryClient,
    QueryClientProvider,
} from '@tanstack/react-query'
import { BrowserRouter } from 'react-router-dom';
import LangProvider from './lang-provider';


const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            refetchOnWindowFocus: false,
            retry: false,
        },
    }
})

export default function Providers({ children }: { children: React.ReactNode }) {
    return (
        <BrowserRouter>
            {/* <ErrorBoundary> */}
                <Suspense fallback={<Loading isLoading={true} />}>
                    <QueryClientProvider client={queryClient}>
                        <AuthProvider>
                            <LangProvider>
                                <ThemeProvider>
                                    {children}
                                </ThemeProvider>
                            </LangProvider>
                        </AuthProvider>
                    </QueryClientProvider>
                </Suspense>
            {/* </ErrorBoundary> */}
        </BrowserRouter>
    )
}