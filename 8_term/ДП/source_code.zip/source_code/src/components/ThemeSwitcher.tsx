import React from 'react';
import IconButton from '@mui/material/IconButton';
import Brightness4Icon from '@mui/icons-material/Brightness4';
import Brightness7Icon from '@mui/icons-material/Brightness7';
import { ThemeContext } from '@/components/providers/theme-provider';

const ThemeSwitcher = () => {
    const { isThemeDark, setIsThemeDark } = React.useContext(ThemeContext)

    const handleSwitch = () => {
        setIsThemeDark(prev => !prev)
        localStorage.setItem("theme", isThemeDark ? "light" : "dark")
    }

    return (
        <IconButton sx={{ ml: 1, alignSelf: "start" }} onClick={handleSwitch} color="inherit">
            {isThemeDark ? <Brightness7Icon /> : <Brightness4Icon />}
        </IconButton>
    )
}

export default ThemeSwitcher