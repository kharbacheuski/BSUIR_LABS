import Header from '@/components/header/Header';
import "./styles/base.scss"
import { Element } from './routes';
import Footer from '@/components/footer/Footer';
import Providers from './components/providers/providers';
import ScrollToTop from './components/ScrollToTop';
import { Box } from '@mui/material';

declare module "@mui/material/styles" {
    interface Palette {
        header: string
    }
    interface PaletteOptions {
        header: string;
    }
}
  
const Main = () => {
    return (
        <Providers>
            <ScrollToTop />
            <Header />
            <Element />
            <Footer />
        </Providers> 
    )
}

export default Main