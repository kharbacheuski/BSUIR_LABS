import { Box, Button, Container, Typography } from "@mui/material"
import ProgressBar from "./components/ProgressBar"
import { useContext, useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import {Helmet} from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { methods } from "@/api/methods";
import AnswerVariants from "./components/AnswerVariants";
import { getAxiosErrorMessage } from "@/utilities/get-axios-error-message";
import AlertComponent, { AlertStateType } from "@/components/AlertComponent";
import salary from "../../../images/salary.svg"
import occupation from "../../../images/occupation.svg"
import profile from "../../../images/profile.svg"
import profile2 from "../../../images/profile2.svg"
import profile3 from "../../../images/profile3.svg"
import occupation2 from "../../../images/occupation2.svg"
import profile4 from "../../../images/profile4.svg"
import { AuthContext } from "@/components/providers/auth-provider";
import { useTranslation } from "react-i18next";

const images = [
    "",
    salary,
    occupation,
    profile,
    profile2,
    profile3,
    occupation2,
    profile4,
    ""
]

enum ButtonState {
    Start = "Start",
    Next = "Next",
    Finish = "Finish"
}

const firstQuestion = {id: "0", value: "Now you need to give some information about yourself. Take the survey", order: 0, questionnaire: ""}
const lastQuestion = {id: "Infinity", value: "We have received the necessary information. You can finish the survey", order: 0, questionnaire: ""}

const Onboarding = () => {
    const params = useParams()
    const questionNumber = Number(params.questionNumber) || 0;
    const navigate = useNavigate()

    const [answers, setAnswers] = useState<OnboardingAnswerMap>({})
    const [buttonText, setButtonText] = useState(Number(questionNumber) ? ButtonState.Next : ButtonState.Start)
    const [isButtonDisabled, setIsButtonDisabled] = useState(false)

    const [alertState, setAlertState] = useState<AlertStateType>({
        isVisible: false,
        message: "",
        severity: "error"
    })

    const {data: questions } = useQuery({
        queryKey: ['onboarding query'], 
        queryFn: async () => {
            const {data} = await methods.onboarding.getQuestions()
            return [firstQuestion, ...data, lastQuestion] as OnboardingQuestion[]
        },
        initialData: [],
    })
    
    const progressStep = Math.round(100/questions.length)

    const takeAnswer = (value) => {
        setAnswers(prev => ({...prev, [questions[questionNumber]?.id]: value}))
    }

    const handleBack = () => {
        if(questionNumber === 0) return
        navigate(`/onboarding/${questionNumber - 1}`)
        setButtonText(ButtonState.Next)
    }

    const next = () => {
        if(questions[questionNumber]?.isRequired && !answers[questions[questionNumber]?.id]) {
            setAlertState({
                isVisible: true,
                message: t("Please answer the question"),
                severity: "error"
            })
            return
        }
        setButtonText(ButtonState.Next)
        navigate(`/onboarding/${questionNumber + 1}`)
        if(questionNumber + 1 === questions.length - 1) {
            setButtonText(ButtonState.Finish)
        }
        setAlertState({isVisible: false, message: "", severity: "error"})
    }

    const handleAction = () => {
        switch(buttonText) {
            case ButtonState.Finish: sendAnswers(); break
            case ButtonState.Next: next(); break;
            case ButtonState.Start: next(); break;
        }
    }

    const sendAnswers = async () => {
        try {
            const data: OnboardingAnswer[] = Object.entries(answers).map(([id, value]) => ({question: id, value}))

            await methods.onboarding.answer(data)

            setIsButtonDisabled(true)

            setAlertState({
                isVisible: true,
                message: t(`Answers saved. Redirect to home page after 3 seconds`),
                severity: "success",
            })


            setTimeout(() => {
                navigate("/")
            }, 3000)
        }
        catch (e) {
            const message = getAxiosErrorMessage(e)

            setAlertState({
                isVisible: true,
                message,
                severity: "error"
            })
        }
    }

    const {t} = useTranslation()

    return <Box className="onboarding-page" sx={{minHeight: "60vh"}}> 
        <Helmet>
            <title>{t("Onboarding")}</title>
            <meta name="description" content="User onboarding"></meta>
        </Helmet>

        <Container className="container">
            <Box sx={{display: "flex", flexDirection: "column", alignItems: "center"}}>
                <ProgressBar progress={(questionNumber + 1) * progressStep} handleBack={handleBack} />

                <Box sx={{width: "600px", maxWidth: "100%", display: "flex", flexDirection: "column"}}>
                    <Typography variant="h5" sx={{margin: "20px 0", textAlign: "center"}}>{t(questions[questionNumber]?.value)}</Typography>

                    <img width={"150px"} style={{margin: "20px auto"}} src={images[questionNumber]} />

                    {questionNumber > 0 && buttonText !== ButtonState.Finish && <AnswerVariants 
                        question={questions[questionNumber]}
                        value={answers[questions[questionNumber]?.id] || ""} 
                        setValue={takeAnswer}
                    />}
                </Box>

                <Box sx={{display: "flex", alignItems: "center", gap: "20px", margin: "20px 0 50px",}}>
                    <Button 
                        sx={{minWidth: "200px"}}
                        variant="contained" 
                        disabled={isButtonDisabled}
                        onClick={handleAction}
                    >
                        {t(buttonText)}
                    </Button>

                    {!questions[questionNumber]?.isRequired 
                    && buttonText !== ButtonState.Finish  
                    && buttonText !== ButtonState.Start &&
                    <Button 
                        sx={{minWidth: "200px"}}
                        variant="contained" 
                        onClick={next}
                        color="secondary"
                    >
                        {t("Skip")}
                    </Button>}
                </Box>

            </Box>
        </Container>

        <AlertComponent 
            isVisible={alertState.isVisible} 
            message={alertState.message} 
            type={alertState.severity} 
            autoCloseTime={alertState.autoCloseTime}
            onCloseHandle={() => setAlertState({isVisible: false, message: "", severity: "error"})} 
        />
    </Box>
}

export default Onboarding