import { Box, FormControl, RadioGroup, FormControlLabel, Radio, Input } from "@mui/material"
import { FC } from "react"
import { useTranslation } from "react-i18next"

const customInputType = {
    "numeric": "number",
    "text": "text"
}

const AnswerVariants: FC<{
    question: OnboardingQuestion,
    value: string, 
    setValue: (value) => void
}> = ({question, value, setValue}) => {
    const isSingleAnswer = !question?.preparedAnswers?.length
    const {t} = useTranslation()

    return <Box sx={{margin: "50px 0"}}>
        {isSingleAnswer ? 
        <Input 
            type={customInputType[question?.answerDatatype]}
            fullWidth 
            sx={{width: "100%", margin: "20px 0"}} 
            placeholder={t("Type your answer")}
            value={value}
            onChange={(e) => setValue(e.target.value)} 
        />
        :
        <FormControl>
            <RadioGroup
                aria-labelledby="demo-radio-buttons-group-label"
                name="radio-buttons-group"
                value={value}
                onChange={(e) => setValue(e.target.value)}
            >
                {question?.preparedAnswers?.map(answer => <FormControlLabel key={answer} value={answer} control={<Radio />} label={t(answer)} />)}
            </RadioGroup>
        </FormControl>}
        {question?.customAnswerAllowed && 
        <Input 
            type={customInputType[question?.answerDatatype]}
            fullWidth 
            sx={{width: "100%", margin: "20px 0"}} 
            placeholder={t("Type other answer")}
            value={value} 
            onChange={(e) => setValue(e.target.value)} 
        />}
    </Box>
}

export default AnswerVariants