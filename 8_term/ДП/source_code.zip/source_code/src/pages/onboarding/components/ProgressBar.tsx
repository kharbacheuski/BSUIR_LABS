import { FC } from "react"
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { Box, createSvgIcon, IconButton, LinearProgress, SvgIcon, useTheme } from "@mui/material";

const ProgressBar: FC<{
    progress: number, 
    isBackButton?: boolean
    handleBack: () => void
}> = ({progress, isBackButton = true, handleBack}) => {
    const theme = useTheme();

    return (
        <Box sx={{display: "flex", alignItems: "center", gap: "30px", width: "100%", margin: "10px 0 20px"}}>
            {isBackButton && <IconButton onClick={handleBack}>
                <ArrowBackIcon sx={{color: theme.palette.text.primary}}/>
            </IconButton>}
            <LinearProgress sx={{width: "100%"}} variant="determinate" value={progress} />
        </Box>
)
}

export default ProgressBar