import { Box, Container, Theme, Typography, useMediaQuery } from "@mui/material"
import PostsList from "../post/posts-list";
import Search from "@/pages/blog/Search";
import { Fragment, useState } from "react";
import BG from '../../../images/search-back.svg'
import {Helmet} from "react-helmet";
import { useTranslation } from "react-i18next";

const Blog = () => {
    const [search, setSearch] = useState<string>("")
    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));
    const {t} = useTranslation()

    return (<Fragment>
        <Helmet>
            <title>{t("Blog")}</title>
            <meta name="description" content="Useful articles from experts for exchange business and crypto market in Limwo blog"></meta>
        </Helmet>

        <Container className="container">
            <Box sx={theme => ({
                margin: mdUp ? "50px 0 20px" : "30px 0 20px", 
                padding: mdUp ? "80px 0" : "30px 0 70px", 
                display: "flex", 
                justifyContent: "center", 
                alignItems: "center",
                background: `url(${BG}) ${theme.palette.background.paper}` ,
                borderRadius: "10px",
                position: "relative",

            })}>
                <Typography variant="h4">{t("Blog")}</Typography>
                <Box sx={{width: mdUp ? "80%" : "94%", position: "absolute", bottom: "-60px"}}>
                    <Search query={search} setQuery={setSearch} />
                </Box>
            </Box>

            <Box sx={{margin: mdUp ? "150px 0 50px" : "100px 0 50px"}}>
                <PostsList search={search} />
            </Box>  
        </Container>
    </Fragment>)
}

export default Blog