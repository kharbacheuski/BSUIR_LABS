import { Box } from "@mui/material";
import { FC } from "react";
import Loupe from "@images/loupe.svg"
import { useTranslation } from "react-i18next";

type SearchProps = {
    query: string,
    setQuery: (query: string) => void
};

const Search: FC<SearchProps> = ({query, setQuery}) => {
    const {t} = useTranslation()

    return (
        <Box className="search" sx={{
            display: "flex",
            alignItems: "center",
            gap: "20px",
            padding: "35px",
            textAlign: "center",
            boxShadow: "0px 10px 20px rgba(0,6,31,.08)",
            borderRadius: "10px",
            backgroundColor: "white",
        }}>
            <img className="loupe" src={Loupe} alt="" />
           
            <Box sx={{width: "100%"}} component={"form"} className="search__form" id="search-form">
                <input style={{
                    all: "unset",
                    fontSize: "18px",
                    lineHeight: "27px",
                    color: "#000",
                    height: "50px",
                    width: "100%",
                    textAlign: "left",
                }} id="search-input" placeholder={t("Some thing...")} aria-label="" value={query} onChange={(e) => setQuery(e.target.value)} /> 
            </Box>
            <Box className="search__result hidden" id="search-result"></Box>
        </Box>
    )
}

export default Search