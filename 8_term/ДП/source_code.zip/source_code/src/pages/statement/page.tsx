import { Box, Typography, useMediaQuery, useTheme, Container } from "@mui/material"
import { methods } from "@/api/methods";
import { DataGrid, GridColDef, GridRenderEditCellParams, GridValueGetterParams } from '@mui/x-data-grid';
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Fragment } from "react";
import {Helmet} from "react-helmet"
import { useTranslation } from "react-i18next";

const getPaymentStatusColor = (status: string) => {
    const theme = useTheme()

    switch(status) {
        case "Pending": return "#858585";
        case "Success": return theme.palette.success.light;
        case "Failed": return theme.palette.error.light;
        case "Rejected": return theme.palette.warning.light;
        default: return theme.palette.text.primary
    }
}

export default function Page() {
    const {data: payments, isLoading } = useQuery({
        queryKey: ['payments statement'], 
        queryFn: async () => (await methods.payment.getPaymentsByWalletNumber()).data,
    })
    
    const theme = useTheme()
    const {t} = useTranslation()

    const columns: GridColDef[] = [
        { 
            field: 'id', 
            headerName: 'ID', 
            width: 90, 
            hideable: false 
        },
        {
            field: 'walletNumber',
            headerName: t('Wallet number'),
            flex: 1,
            minWidth: 100,
            editable: false,
            renderCell: (params: GridRenderEditCellParams) => {
                return (
                    <Link style={{color: theme.palette.text.primary}} to={`/payments/${params.row.walletNumber}`}>
                        {params.row.walletNumber}
                    </Link>
                )
            }
        },
        {
            field: 'paymentTypeCode',
            headerName: t('Payment Type'),
            flex: 1,
            minWidth: 100,
            editable: false,
        },
        {
            field: 'balanceOperationTypeCode',
            headerName: t('Operation Type'),
            flex: 1,
            minWidth: 80,
            editable: false,
            renderCell: (params: GridRenderEditCellParams) => <Typography 
                sx={{
                    marginLeft: "5px",
                    color: params.row.balanceOperationTypeCode == "Credit" ? theme.palette.success.light : theme.palette.error.light, 
                    display: "inline-block"
                }}
            >
                {params.row.balanceOperationTypeCode}
            </Typography>
        },
        {
            field: 'amount',
            headerName: t('Amount'),
            type: 'number',
            flex: 0.5,
            minWidth: 100,
            align: 'center',
            editable: false,
        },
        {
            field: 'created',
            headerName: t('Created'),
            flex: 0.8,
            minWidth: 100,
            valueGetter: (params: GridValueGetterParams) => `${new Date(params.row.created).toLocaleDateString()}`,
        },
        {
            field: 'paymentStatusCode',
            headerName: t('Status'),
            flex: 1,
            minWidth: 100,
            align: 'right',
            headerAlign: 'right',
            renderCell: (params: GridRenderEditCellParams) => <Typography 
                    sx={{
                        marginLeft: "5px",
                        color: getPaymentStatusColor(params.row.paymentStatusCode), 
                        display: "inline-block"
                    }}
                >
                {t(params.row.paymentStatusCode)}
            </Typography>,     
        },
    ];

    return (<Fragment>
            <Helmet>
                <title>{t("Statement")}</title>
                <meta name="description" content="The statement is a list of all user transactions from all wallets and includes all the necessary information"></meta>
            </Helmet>
            <Container className="container">
                <Box sx={{display: "flex", flexDirection: "column", gap: "20px", alignItems: "center", padding: "50px 0"}}>
                    <Typography sx={{width: "max-content"}} variant="h5">{t("Wallets statement")}</Typography>
                    <DataGrid
                        autoHeight
                        sx={{
                            width: "100%",
                        }}
                        rows={payments || []}
                        columns={columns}
                        initialState={{
                            pagination: {
                                paginationModel: {
                                    pageSize: 10,
                                },
                            },
                        }}
                        pageSizeOptions={[10, 20, 50]}
                        disableRowSelectionOnClick
                        getRowId={(row) => row.created}
                        columnVisibilityModel={{
                            id: false,
                        }}
                        loading={isLoading}
                    />  
                </Box>
            </Container>
        </Fragment>
    );
};