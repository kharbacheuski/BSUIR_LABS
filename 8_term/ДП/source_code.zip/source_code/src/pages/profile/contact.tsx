import { Box, Typography, useTheme, SvgIcon, IconButton } from "@mui/material"
import { methods } from "@/api/methods";
import { useEffect, useState } from "react";
import AlertComponent, { AlertStateType } from "@/components/AlertComponent";
import EmailIcon from '@mui/icons-material/Email';
import PhoneEnabledIcon from '@mui/icons-material/PhoneEnabled';
import CreateContact from "./create-contact";
import { useQuery } from "@tanstack/react-query";
import CloseIcon from '@mui/icons-material/Close';
import { AxiosError } from "axios";
import { getAxiosErrorMessage } from "@/utilities/get-axios-error-message";
import { useTranslation } from "react-i18next";

const ContactRow = ({contact, handleDelete}) => {

    return (
        <Box key={contact.value} sx={{display: "flex", gap: "6px", alignItems: "center"}}>
            <SvgIcon component={contact.contactType == "Email" ? EmailIcon : PhoneEnabledIcon} sx={{width: "20px", height: "20px"}}/>
            <Typography sx={{width: "max-content", fontWeight: "bold"}}>
                {contact.contactType}&#58;
            </Typography>
            <Typography sx={{width: "max-content"}}>
                {contact.value}
            </Typography>

            <SvgIcon 
                component={CloseIcon} 
                sx={{
                    width: "20px", 
                    height: "20px", 
                    cursor: "pointer",
                }}
                onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation()
                    handleDelete(contact.value)
                }}
            />
        </Box>
    )
}

export default function ContactInfo() {
    const [alertState, setAlertState] = useState<AlertStateType>({
        isVisible: false,
        message: "",
        severity: "success",
    })

    const theme = useTheme()

    const {data: contacts, isLoading, refetch} = useQuery({
        queryKey: ["contacts"], 
        queryFn: async () => {
            const {data} = await methods.contact.getContacts();

            return data
        },
    })

    const handleDelete = async (value: string) => {
        try {
            await methods.contact.deleteContact({value})

            setAlertState({
                isVisible: true,
                message: "Contact deleted",
                severity: "success",
            })

            refetch()
        }
        catch(e: AxiosError | any) {
            const message = getAxiosErrorMessage(e)

            setAlertState({
                isVisible: true,
                message: message,
                severity: "error"
            })
        }
    }

    const {t} = useTranslation()

    return (
        <Box sx={{width: "100%", marginTop: "40px"}}>
            <Box sx={{display: "flex", gap: "10px", flexDirection: "column", marginTop: "10px"}}>
                <Typography variant="h5" sx={{width: "max-content"}}>{t("Your contacts")}: </Typography>

                {contacts?.length 
                ? contacts?.map(contact => <ContactRow key={contact.value} contact={contact} handleDelete={handleDelete} />)
                : <Typography sx={{width: "max-content"}}>{t("No contacts yet")}</Typography>}
            </Box>

            <CreateContact refetch={refetch}/>

            <AlertComponent 
            isVisible={alertState.isVisible} 
            message={alertState.message} 
            type={alertState.severity} 
            onCloseHandle={() => setAlertState({isVisible: false, message: "", severity: "error"})} 
        />
        </Box>
    )
}