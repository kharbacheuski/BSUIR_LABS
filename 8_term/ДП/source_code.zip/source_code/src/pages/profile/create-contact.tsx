import { Box, Typography, TextField, Button } from "@mui/material"
import { methods } from "@/api/methods";
import { Fragment, useState } from "react";
import { 
    FormControl, 
    InputLabel, 
    Select, 
    MenuItem,
} from "@mui/material"
import AlertComponent, { AlertStateType } from "@/components/AlertComponent";
import {AxiosError} from "axios";
import { getAxiosErrorMessage } from "@/utilities/get-axios-error-message";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";

const validation = (type: string, value: string) => {
    switch(type) {
        case "Email":
            return /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(value)
        case "Phone":
            return /^[+]*[-\s]{0,1}[\d]{3}[-\s]{0,1}[(]{0,1}(17|29|33|44|25)[)]{0,1}[-\s\.\d]{7}$/.test(value)
        default:
            return false
    }
}

type Props = {
    refetch
}

export default function CreateContact({refetch}: Props) {
    const {t} = useTranslation()

    const [alertState, setAlertState] = useState<AlertStateType>({
        isVisible: false,
        message: "",
        severity: "success",
    })

    const {data: contactTypes, isLoading} = useQuery({
        queryKey: ["contactTypes"], 
        queryFn: async () => {
            const {data} = await methods.contact.getTypes();

            return data
        },
    })

    const createContact = async (event) => {
        try {
            event.preventDefault()

            setAlertState({
                isVisible: false,
                message: "",
                severity: "error"
            })

            const formData = new FormData(event.currentTarget)

            const contactType = formData.get('contactType') as string
            const value = formData.get('value') as string

            if(!validation(contactType, value)) {
                const message = `Validation error: Invalid ${contactType} value`

                throw new Error(message);
            }

            await methods.contact.createContact({contactType, value});

            refetch()
        }
        catch(e: AxiosError | any) {
            const message = getAxiosErrorMessage(e)

            setAlertState({
                isVisible: true,
                message: message,
                severity: "error"
            })
        }
    }

    return <Fragment>
        <Box sx={{display: "flex", flexDirection: "column", gap: "10px", marginTop: "50px"}}>
            <Typography variant="h5" sx={{width: "max-content"}}>{t("Add contact")}:</Typography>
            <Box component={"form"} onSubmit={createContact} sx={{display: "flex", gap: "10px", flexDirection: "column", marginTop: "0px"}}>
                <Box sx={{display: "flex", gap: "10px"}}>
                    <FormControl sx={{width: "300px"}}>
                        <InputLabel id="contact-type">{t("Contact type")}</InputLabel>
                        <Select
                            name="contactType"
                            labelId="contact-type"
                            label={t("Contact type")}
                        >
                            {contactTypes?.map(contactType => (
                                <MenuItem key={contactType.code} value={contactType.code}>{contactType.code}</MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <TextField sx={{width: "300px"}} name="value" label={t("Contact value")} variant="outlined" />
                </Box>

                <Button sx={{width: "200px"}} type="submit" variant="contained">{t("Add contact")}</Button>
            </Box>
        </Box>

        <AlertComponent 
            isVisible={alertState.isVisible} 
            message={alertState.message} 
            type={alertState.severity} 
            onCloseHandle={() => setAlertState({isVisible: false, message: "", severity: "error"})} 
        />
    </Fragment>
}