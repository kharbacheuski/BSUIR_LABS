import { useEffect, useState } from "react";
import { methods } from "@/api/methods";
import { Box, Theme, Typography, useMediaQuery, useTheme } from "@mui/material"
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import Loader from "@/components/Loader";
import { useTranslation } from "react-i18next";

const LoginActivity = () => {
    const [loginsList, setLoginsList] = useState<LoginActivityType[]>([])
    const [loading, setLoading] = useState<boolean>(false)

    const {t} = useTranslation()

    const getLoginActivity = async () => {
        try {
            setLoading(true)
            const {data} = await methods.user.loginActivity();

            setLoginsList(data)
        }
        catch(e) {
            console.error(e)
        }
        finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        getLoginActivity()
    }, [])

    const columns: GridColDef[] = [
        { 
            field: 'id', 
            headerName: 'ID', 
            hideable: false, 
            flex: 1
        },
        {
            field: 'type',
            headerName: t('Type'),
            flex: 1
        },
        {
            field: 'device',
            headerName: t('Device'),
            flex: 1
        },
        {
            field: 'ipAddress',
            headerName: t('IP Address'),
            editable: false,
            flex: 1
        },
        {
            field: 'loginDate',
            headerName: t('Date'),
            flex: 1,
            valueFormatter: (params) => new Date(params.value).toLocaleString()
        },
    ];

    const theme = useTheme()
    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));

    return (
        <Box 
            sx={{
                padding: mdUp ? "30px" : "0", 
                backgroundColor: mdUp ? theme.palette.background.paper : theme.palette.background.default, 
                borderRadius: "10px", 
                width: "100%", 
                marginTop: "20px"
            }}
        >
            <Typography sx={{width: "max-content"}}>{t("Login Activity")}</Typography>

            <Box sx={{ marginTop: "10px"}}>
                <DataGrid
                    rows={loginsList}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: {
                                pageSize: 5,
                            },
                        },
                    }}
                    pageSizeOptions={[5, 10, 20, 50]}
                    disableRowSelectionOnClick
                    getRowId={(row) => Math.random().toString(16).slice(2)}
                    columnVisibilityModel={{
                        id: false,
                    }}
                />
            </Box>

            <Loader isLoading={loading}/>
        </Box>
    )
}

export default LoginActivity;