import { Box, Typography, TextField, Button, useTheme } from "@mui/material"
import { methods } from "@/api/methods";
import { useState } from "react";
import { 
    FormControl, 
    InputLabel, 
    InputAdornment, 
    OutlinedInput,
    IconButton, 
} from "@mui/material"
import { Visibility, VisibilityOff } from '@mui/icons-material';
import AlertComponent, { AlertStateType } from "@/components/AlertComponent";
import { useTranslation } from "react-i18next";
import { jwtDecode } from "jwt-decode";

const ProfileInfo = () => {
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const [creds, setCreds] = useState<UserCredentialsType>({
        name: "",
        password: "",
    })

    const [alertState, setAlertState] = useState<AlertStateType>({
        isVisible: false,
        message: "",
        severity: "success",
    })

    const theme = useTheme()

    const {name} = jwtDecode(localStorage.getItem("token") || "") as any

    const changePassword = async () => {
        try {
            await methods.user.changePassword({password: creds.password});

            setAlertState({
                isVisible: true,
                message: "Password changed",
                severity: "success"
            })
        }
        catch(e) {
            console.error(e)

            setAlertState({
                isVisible: true,
                message: "Something went wrong",
                severity: "error"
            })
        }
    }

    const {t} = useTranslation()

    return (
        <Box sx={{width: "100%", marginTop: "20px"}}>
            <Typography sx={{width: "max-content"}}>{t("Basic details")}</Typography>

            <Box sx={{width: '100%', maxWidth: "500px"}}>
                <Box sx={{display: "flex", flexDirection: "column", flexWrap: "wrap", gap: "10px", alignItems: "flex-end", marginTop: "10px"}}>
                    <TextField fullWidth label={t("Username")} variant="outlined" value={name} disabled/>
                </Box>

                <Box sx={{display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "flex-end", marginTop: "10px"}}>
                    <FormControl sx={{width: '100%', maxWidth: "300px"}} variant="outlined">
                        <InputLabel htmlFor="outlined-adornment-password">{t("Password")}</InputLabel>
                        <OutlinedInput
                            type={showPassword ? 'text' : 'password'}
                            endAdornment={
                                <InputAdornment position="end">
                                    <IconButton
                                        aria-label="toggle password visibility"
                                        onClick={() => setShowPassword(!showPassword)}
                                        onMouseDown={(e) => e.preventDefault()}
                                        edge="end"
                                    >
                                    {showPassword ? <VisibilityOff /> : <Visibility />}
                                    </IconButton>
                                </InputAdornment>
                            }
                            label={t("Password")}
                            onChange={(e) => setCreds({...creds, password: e.target.value})}
                        />
                    </FormControl>

                    <Button sx={{width: "200px"}} variant="contained" color="primary" onClick={changePassword}>{t("Change password")}</Button>
                </Box>
            </Box>

            <AlertComponent 
                isVisible={alertState.isVisible} 
                message={alertState.message} 
                type={alertState.severity} 
                onCloseHandle={() => setAlertState({isVisible: false, message: "", severity: "error"})} 
            />
        </Box>
    )
}

export default ProfileInfo