import { Box, Typography, useTheme, Button } from "@mui/material"
import { Fragment, useState, useContext } from "react"
import ModalWindow from "@/components/ModalWindow";
import { methods } from "@/api/methods";
import { AuthContext } from "@/components/providers/auth-provider";
import { useTranslation } from "react-i18next";

const DeleteAccount = () => {
    const theme = useTheme()
    const {t} = useTranslation()

    const [isSubmissionVisible, setIsSubmissionVisible] = useState<boolean>(false)

    const {setIsAuth} = useContext(AuthContext)

    const deleteAccount = async () => {
        try {
            await methods.user.deleteAccount()

            setIsAuth(false)
            localStorage.clear()
        }
        catch(e) {
            console.error(e)
        }
    }

    return (<Fragment>
        <Box sx={{borderRadius: "10px", width: "100%", marginTop: "40px"}}>
            <Typography>{t("Delete your account and all of your source data. This is irreversible.")}</Typography>

            <Button onClick={() => setIsSubmissionVisible(true)} sx={{marginTop: "10px"}} variant="contained" color="error">{t("Delete Account")}</Button>
        </Box>

        <ModalWindow isVisible={isSubmissionVisible} handleClose={() => setIsSubmissionVisible(false)}>
            <Typography align="center" variant="h5">{t("Are you sure you want to delete your account?")}</Typography>

            <Box sx={{ display: "flex", gap: "10px", marginTop: "20px", flexWrap: "wrap", justifyContent: "center" }}>
                <Button onClick={() => deleteAccount()} sx={{ width: "250px" }} variant="contained">{t("Delete")}</Button>
                <Button color="secondary"  onClick={() => setIsSubmissionVisible(false)} sx={{ width: "250px" }} variant="contained">{t("Cancel")}</Button>
            </Box>   
        </ModalWindow>
    </Fragment>)
}

export default DeleteAccount