import { Box, Container } from "@mui/material"
import LoginActivity from "./login-activity";
import ProfileInfo from "./profile-info";
import AvatarFlow from "./avatar";
import DeleteAccount from "./delete-account";
import ContactInfo from "./contact";
import {Helmet} from "react-helmet"
import { Fragment } from "react";
import { useTranslation } from "react-i18next";

export default function Page() {
    const {t} = useTranslation()

    return (<Fragment>
            <Helmet>
                <title>{t("Profile")}</title>
                <meta name="description" content={`Limwo profile`}></meta>
            </Helmet>
            <Container className="container">
                <Box sx={{padding: "30px 0"}}>
                    <AvatarFlow />
                    <ProfileInfo />
                    <LoginActivity />
                    <ContactInfo />
                    <DeleteAccount />
                </Box>
            </Container>
        </Fragment>
    );
};