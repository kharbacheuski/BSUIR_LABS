import { Box, Stack, SvgIcon, Avatar } from "@mui/material"
import { methods } from "@/api/methods";
import CameraAltIcon from '@mui/icons-material/CameraAlt';
import { useQuery } from "@tanstack/react-query";

const AvatarFlow = () => {
    const {data: base64Avatar, refetch} = useQuery({
        queryKey: ["avatar"], 
        queryFn: async () => {
            const data = await methods.user.getAvatar();
            
            return data
        },
    })

    const handleChangeAvatar = async (event: React.ChangeEvent<HTMLInputElement>) => {
        try {
            let formData: any = new FormData();
            formData.append('file', event.target.files![0]);

            await methods.user.setAvatar(formData);

            refetch()
        }
        catch(e) {
            console.error(e)
        }
    }

    return (
        <Stack
            alignItems="center"
            direction="row"
            spacing={2}
        >
            <Box
                sx={{
                    borderColor: 'neutral.300',
                    borderRadius: '50%',
                    borderStyle: 'dashed',
                    borderWidth: 1,
                    p: '4px',
                }}
            >
                <Box
                    sx={{
                        borderRadius: '50%',
                        height: '100%',
                        width: '100%',
                        position: 'relative',
                    }}
                >
                    <Box
                        component="label"

                        sx={{
                            alignItems: 'center',
                            borderRadius: '50%',
                            color: 'common.white',
                            cursor: 'pointer',
                            display: 'flex',
                            height: '100%',
                            justifyContent: 'center',
                            left: 0,
                            opacity: 0,
                            position: 'absolute',
                            top: 0,
                            width: '100%',
                            zIndex: 1,

                            '&:hover': {
                                opacity: 1,
                            },
                        }}
                    >
                        <SvgIcon color="inherit">
                            <CameraAltIcon />
                        </SvgIcon>
                        <input
                            type="file"
                            hidden
                            onChange={handleChangeAvatar}
                        />
                    </Box>
                    
                   
                    <Avatar
                        alt="avatar"
                        src={base64Avatar}
                        sx={{
                            height: 150,
                            width: 150,
                        }}
                    />
                </Box>
            </Box>
        </Stack>
    )
}

export default AvatarFlow