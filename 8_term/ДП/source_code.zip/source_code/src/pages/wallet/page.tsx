import { Box, Container, Theme, Typography, useMediaQuery } from "@mui/material"
import { methods } from "@/api/methods";
import CreateWallet from "./create-wallet";
import WalletsList from "./wallet-list";
import CurrencyRates from "@/components/CurrencyRates";
import PostsList from "../post/posts-list";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Fragment } from "react";
import { useTranslation } from "react-i18next";

export default function Page() {
    const {data: wallets, isLoading, refetch} = useQuery({
        queryKey: ["get-wallets"], 
        queryFn: async () => {
            const {data} = await methods.wallet.getWallets();

            return data
        },
    })

    const {t} = useTranslation()

    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));

    return (<Fragment>
            <Box component={"section"}>
                <Container className="container">
                    <Typography sx={{margin: "50px 0 20px", transitionDelay: "0.0s"}} variant="h5" data-animate-top>{t("Currency rates")}:</Typography>

                    <Box sx={{display: "flex", gap: mdUp ? "20px" : "10px", flexWrap: "wrap"}}>
                        <CurrencyRates />
                    </Box>

                    <Typography sx={{margin: mdUp ? "100px 0 20px" : "50px 0 20px"}} variant="h5">{t("Your wallets")}:</Typography>

                    <CreateWallet refetch={refetch} />

                    <WalletsList wallets={wallets || []} refetch={refetch}/>
                </Container>
            </Box>
            <Box component={"section"} sx={{padding: mdUp ? "100px 0" : "50px 0", background: `url(${process.env.PUBLIC_URL + "/images/section-bg.png"})`}}>
                <Container className="container">
                    <Box sx={{display: "flex", flexDirection: "column", justifyContent: "center"}}>
                        <Link to={"/blog"} style={{textDecoration: "none", color: "inherit", fontWeight: 700, marginBottom: "10px", display: "inline-block"}}>{t("View more posts")}</Link>
                        <PostsList grid count={3} />
                    </Box>
                </Container>
            </Box>
        </Fragment>
    )
};