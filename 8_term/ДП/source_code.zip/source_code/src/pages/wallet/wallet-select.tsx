import { methods } from "@/api/methods";
import { useQuery } from "@tanstack/react-query";
import { FC, useEffect, useState, ChangeEvent } from "react";
import {
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    SelectProps,
    FormHelperText,
    Autocomplete,
    TextField,
    SelectChangeEvent
} from "@mui/material";
import { useTranslation } from "react-i18next";

type WalletTypeSelect = WalletType & {
    label: string;
};

interface WalletSelectProps extends SelectProps {
    value: string;
    setValue: (wallet: WalletTypeSelect | string) => void;
    anyWallet?: boolean;
}

const WalletSelect: FC<WalletSelectProps> = ({
    value,
    setValue,
    anyWallet = false,
    ...props
}) => {
    const { t } = useTranslation();
    const [walletBalance, setWalletBalance] = useState<number>(0);

    const { data: wallets = [], isLoading } = useQuery<WalletTypeSelect[]>({
        queryKey: ["get-wallets"],
        queryFn: async () => {
            const { data } = await methods.wallet.getWallets();
            return data.map(wallet => ({
                ...wallet,
                label: `${wallet.number} (${wallet.currencyCode})`
            }));
        },
        refetchOnWindowFocus: false
    });

    const selectedWallet = wallets.find(wallet => wallet.number === value) || null;

    const handleSelectChange = (e: SelectChangeEvent<unknown>) => {
        const selected = wallets.find(wallet => wallet.number === e.target.value);
        if (selected) setValue(selected);
    };

    const fetchWalletBalance = async () => {
        const { data } = await methods.wallet.getWalletBalance(value);
        setWalletBalance(data.value);
    };

    useEffect(() => {
        if (value) fetchWalletBalance();
    }, [value]);

    if (anyWallet) {
        return (
            <Autocomplete
                disablePortal
                options={wallets}
                value={selectedWallet}
                inputValue={value}
                sx={{ maxWidth: 350, width: "100%" }}
                renderInput={(params) => <TextField helperText={t("Any wallet (including one of yours)")} {...params} label={props.label} />}
                onChange={(_, wallet) => {
                    if (wallet) setValue(wallet.number);
                }}
                onInputChange={(event, newValue) => {
                    if (event?.type === "change") setValue(newValue);
                }}
            />
        );
    }

    return (
        <FormControl sx={{ maxWidth: 350, width: "100%" }}>
            <InputLabel id="wallet-select-label">{props.label}</InputLabel>
            <Select
                labelId="wallet-select-label"
                value={value}
                onChange={handleSelectChange}
                {...props}
            >
                {!wallets.length && <MenuItem value={"No wallets"}>{t("No wallets")}</MenuItem>}
                {wallets.map(({ number, label}) => <MenuItem value={number} key={number}>{label}</MenuItem>)}
            </Select>
            {value && <FormHelperText>{`${t("Current balance")}: ${walletBalance}`}</FormHelperText>}
        </FormControl>
    );
};

export default WalletSelect;