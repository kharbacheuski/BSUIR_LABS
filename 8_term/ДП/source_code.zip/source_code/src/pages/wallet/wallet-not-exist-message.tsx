import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import { RouterLink } from '@/components/RouterLink';
import { useTranslation } from 'react-i18next';

const WalletNotExist = () => {
    const {t} = useTranslation()

    return (
        <Box
            sx={{
                alignItems: 'center',
                display: 'flex',
                flexGrow: 1,
                py: '80px',
                // height: "calc(100vh - 100px)"
            }}
        >
            <Container maxWidth="lg">
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'center',
                        mb: 3,
                    }}
                >
                    <Typography variant={'h2'} sx={{fontWeight: 700}}>
                        {t("Wallet doesn't exist")}
                    </Typography>
                </Box>
                <Typography
                    align="center"
                    color="text.secondary"
                    sx={{ mt: 0.5 }}
                >
                    {t("We couldn't find the wallet you're looking for. The wallet may have been deleted")}
                </Typography>
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'center',
                        mt: 6,
                    }}
                >
                    <Button
                        component={RouterLink}
                        to={"/"}
                    >
                        {t("Back to Wallets")}
                    </Button>
                </Box>
            </Container>
        </Box>
    );
};

export default WalletNotExist;