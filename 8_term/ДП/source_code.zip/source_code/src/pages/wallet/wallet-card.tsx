import { Box, Typography, Card, CardContent, useTheme, IconButton, Select, FormControl, MenuItem, InputLabel, Button, useMediaQuery, Theme, Tooltip, Snackbar } from "@mui/material"
import { methods } from "@/api/methods";
import {Fragment, useState } from "react";
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import DeleteIcon from '@mui/icons-material/Delete';
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import ModalWindow from "@/components/ModalWindow";
import { useTranslation } from "react-i18next";
import ContentCopyIcon from '@mui/icons-material/ContentCopy';

const WalletCard: React.FC<{
    wallet: WalletType, 
    refetch: () => void
}> = ({wallet, refetch}) => {
    const [isBalanceVisible, setIsBalanceVisible] = useState<boolean>(false)
    const [isSubmissionVisible, setIsSubmissionVisible] = useState<boolean>(false)
    const [isNumberCopied, setIsNumberCopied] = useState<boolean>(false)

    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));

    const {data: walletBalance} = useQuery({
        queryKey: ["walletBalance", wallet?.number], 
        queryFn: async () => {
            const {data} = await methods.wallet.getWalletBalance(wallet?.number)
            return data.value
        }
    })

    const {t} = useTranslation()
    const theme = useTheme()

    const handleBalance = (e: React.MouseEvent<HTMLElement>) => {
        e.preventDefault();
        e.stopPropagation()
        
        setIsBalanceVisible(prev => !prev)
    }

    const deleteWallet = async (walletNumber: string) => {
        try {
            await methods.wallet.delete(walletNumber)

            refetch()
        }
        catch(e) {
            console.error(e)
        }
    }

    const copy = (e, walletNumber) => {
        e.preventDefault();
        e.stopPropagation()

        navigator.clipboard.writeText(walletNumber);
        setIsNumberCopied(true)
    }

    return (<Fragment>
        <Link to={`/payments/${wallet?.number}`} style={{textDecoration: "none", color: "inherit"}}>
            <Card
                sx={{ 
                    padding: mdUp ? "25px 15px" : "10px", 
                    borderRadius: "10px", 
                    backgroundColor: theme.palette.background.paper,
                    boxShadow: "none",
                    cursor: "pointer",
                    backdropFilter: "saturate(180%) blur(10px)",
                    backgroundImage: "none",
                    border: "1px solid transparent",
                }}
            >
                <CardContent sx={{display: "flex", flexDirection: "row", justifyContent: "space-between", position: "relative"}}>
                    <Box sx={{display: "flex", flexDirection: "column", gap: "0px"}}>
                        <Box sx={{paddingRight: "15px", display: "flex", alignItems: "center", gap: "5px"}}>
                            {t("Wallet number")}: 
                            <Tooltip title={t("Copy")} onClick={(e) => copy(e, wallet.number)}>
                                <Typography sx={{color: theme.palette.primary.main, display: "inline"}}>{wallet.number}</Typography>
                            </Tooltip>
                        </Box>
                        <Typography>{t("Currency")}: {wallet.currencyCode}</Typography>
                        <Box sx={{display: "flex", alignItems: "center", gap: "10px"}}>
                            <Typography>{t("Balance")}: {isBalanceVisible ? walletBalance?.toFixed(2) : ""}</Typography>
                            <IconButton onClick={handleBalance}>
                                {isBalanceVisible ? <VisibilityOffIcon/> : <VisibilityIcon />}
                            </IconButton>
                        </Box>
                        <IconButton onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation()
                            setIsSubmissionVisible(prev => !prev)
                        }} sx={{position: "absolute", bottom: "0px", right: "10px"}}>
                            <DeleteIcon />
                        </IconButton>
                    </Box>
                </CardContent>
            </Card>
        </Link>

        <ModalWindow isVisible={isSubmissionVisible} handleClose={() => setIsSubmissionVisible(false)}>
            <Typography variant="h5">{t("Are you sure you want to delete this wallet?")}</Typography>

            <Box sx={{ display: "flex", gap: "10px", marginTop: "20px" }}>
                <Button onClick={() => deleteWallet(wallet.number)} sx={{ width: "250px" }} variant="contained">{t("Delete")}</Button>
                <Button color="secondary"  onClick={() => setIsSubmissionVisible(false)} sx={{ width: "250px" }} variant="contained">{t("Cancel")}</Button>
            </Box>   
        </ModalWindow>

        <Snackbar
            open={isNumberCopied}
            autoHideDuration={2000}
            onClose={() => setIsNumberCopied(false)}
            message={t("Wallet number copied to clipboard")}
        />
    </Fragment>);
};

export default WalletCard