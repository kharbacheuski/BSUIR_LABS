import { Box, Typography, Select, FormControl, MenuItem, InputLabel, Button, useMediaQuery, Theme  } from "@mui/material"
import { methods } from "@/api/methods";
import React, { Fragment, useEffect, useState } from "react";
import ModalWindow from "@/components/ModalWindow";
import AlertComponent, { AlertStateType } from "@/components/AlertComponent";
import { AxiosError } from "axios";
import { getAxiosErrorMessage } from "@/utilities/get-axios-error-message";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";

const CreateWallet: React.FC<{refetch}> = ({refetch}) => {
    const {t} = useTranslation()

    const [currency, setCurrency] = useState<CurrencyType>({
        currencyCode: ""
    })
    const [isCreating, setIsCreating] = useState<boolean>(false)

    const selectHandle = (event) => {
        const {name, value} = event.target

        setCurrency({currencyCode: value})
    }

    const [alertState, setAlertState] = useState<AlertStateType>({
        isVisible: false,
        message: "",
        severity: "success",
    })

    const createWallet = async () => {
        if(!isCreating) {
            setIsCreating(true)
            return
        }
        try {
            const {data: newWallet} = await methods.wallet.create({currencyCode: currency.currencyCode});
            
            refetch()
        }
        catch(e: AxiosError | any) {
            const message = getAxiosErrorMessage(e)

            setAlertState({
                isVisible: true,
                message: message,
                severity: "error"
            })
        }
        finally {
            setIsCreating(false)
        }
    }

    const {data: currencies} = useQuery({
        queryKey: ["currencies"], 
        queryFn: async () => {
            const {data} = await methods.currency.getCurrencies()
            return data
        },
    })
    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));

    return (<Box>
        <ModalWindow isVisible={isCreating} handleClose={() => setIsCreating(false)}>
            <Typography variant="h5">{t("Create new wallet")}</Typography>

            <Box sx={{ width: mdUp ? 450 : "100%" }}>
                <FormControl fullWidth>
                    <InputLabel id="demo-simple-select-label">{t("Currency")}</InputLabel>
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={currency.currencyCode}
                        label={t("Currency")}
                        onChange={selectHandle}
                    >
                        {currencies?.map(cur => <MenuItem key={cur.code} value={cur.code}>{cur.code}</MenuItem>)}
                    </Select>
                </FormControl>
                <Typography sx={{marginTop: "15px", fontStyle: "italic"}}>{t("Selected currency can't be changed")}</Typography>
            </Box>   

            <Box sx={{ display: "flex", gap: "10px", marginTop: "20px" }}>
                <Button onClick={createWallet} variant="contained">{t("Create")}</Button>
                <Button color="secondary" onClick={() => setIsCreating(false)} variant="contained">{t("Cancel")}</Button>
            </Box>
        </ModalWindow>

        <Button onClick={() => setIsCreating(true)} sx={{ width: "250px" }} variant="contained">{t("Create")}</Button>
        <AlertComponent 
            isVisible={alertState.isVisible} 
            message={alertState.message} 
            type={alertState.severity} 
            onCloseHandle={() => setAlertState({isVisible: false, message: "", severity: "error"})} 
        />
    </Box>);
};

export default CreateWallet