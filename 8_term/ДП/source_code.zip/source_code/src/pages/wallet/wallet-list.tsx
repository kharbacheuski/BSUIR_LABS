import { Box } from "@mui/material"
import WalletCard from "./wallet-card";

const WalletsList: React.FC<{
    wallets: WalletType[], 
    refetch: () => void
}> = ({wallets, refetch}) => {

    return (
        <Box sx={{
            display: "grid", 
            gridTemplateColumns: "1fr 1fr", 
            gap: "15px", 
            margin: "20px 0 50px",

            "@media (max-width: 767px)": {
                gridTemplateColumns: "1fr",
            }
        }}>
            {wallets.map((wallet) => wallet && <WalletCard refetch={refetch} key={wallet?.number} wallet={wallet} />)}
        </Box>
    );
};

export default WalletsList