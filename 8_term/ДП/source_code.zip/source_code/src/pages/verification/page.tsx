import { Box, Container, Typography } from "@mui/material"
import { methods } from "@/api/methods";
import {  useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Fragment, useState } from "react";
import { useTranslation } from "react-i18next";
import { HttpStatusCode } from "axios";
import DoneIcon from '@mui/icons-material/Done';
import ErrorIcon from '@mui/icons-material/Error';
import Loader from "@/components/Loader";

export default function Page() {
    const [params, ] = useSearchParams()
    const secret = params.get("secret")

    const [verificationSuccess, setVerificationSuccess] = useState(false);

    const {data, isLoading} = useQuery({
        queryKey: ["get-verification-status"], 
        queryFn: async () => {
            const data = await methods.user.verification({secret: secret || ""});

            setVerificationSuccess(data.status == HttpStatusCode.Ok)

            return data
        },
        enabled: secret !== null
    })

    const {t} = useTranslation()

    const Icon = verificationSuccess ? DoneIcon : ErrorIcon

    return (
        isLoading ? <Loader isLoading={true} /> : <Fragment>
            <Box component={"section"}>
                <Container className="container">
                    <Box sx={{display: "flex", flexDirection: "column", gap: "20px", alignItems: "center"}}>
                        <Icon sx={theme => ({fontSize: "100px", color: verificationSuccess ? "success" : "error", fill: theme.palette.primary.main})}/>

                        <Typography variant="h4" align="center" data-animate-top>{t(verificationSuccess ? "Verification was successful!" : "Verification failed...")}</Typography>
                        {!verificationSuccess && <Typography align="center" data-animate-top>{t("There were problems verifying your account via email. Contact support")}</Typography>}
                    </Box>
                </Container>
            </Box>
        </Fragment>
    )
};