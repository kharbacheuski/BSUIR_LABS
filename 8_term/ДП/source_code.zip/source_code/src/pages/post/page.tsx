import { Typography, Box, Container } from "@mui/material"
import { Fragment } from "react"
import { methods } from "@/api/methods";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import Loader from "@/components/Loader";
import {Helmet} from "react-helmet";

const Post = () => {
    const {slug} = useParams()


    const {data: post, isLoading, isFetched} = useQuery({
        queryKey: ["single post"], 
        queryFn: async () => {
            const {data} = await methods.blog.getSinglePost(slug!)
            return data
        },
    })

    if(isLoading || !isFetched) {
        return <Loader isLoading={true} />
    }
    
    return (<Fragment>
            <Helmet>
                <title>{post?.title}</title>
                <meta name="description" content={`Limwo blog: ${post?.title}`}></meta>
            </Helmet>
            <Container maxWidth="md" className="container">
                <Box>
                    <Typography sx={{margin: "100px 0 50px", textAlign: "center", fontSize: "50px"}} variant="h1">{post?.title}</Typography>

                    <Container  maxWidth="md">
                        <div className="content"  dangerouslySetInnerHTML={{__html: post?.content as TrustedHTML}} />
                    </Container>
                
                    <Typography sx={{margin: "100px 0 50px", textAlign: "right"}}>{new Date(post?.created as string).toDateString()}</Typography>
                </Box>
            </Container>
        </Fragment>
    )
}

export default Post