import { Card, CardContent, Typography, CardActions, Button } from "@mui/material"
import { FC } from "react"
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";

const PostCard: FC<PostType> = ({title, description, slug, imageUrl}) => {
    const navigate = useNavigate()
    const {t} = useTranslation()

    return (
        <Card 
            className="post_card" 
            sx={theme => ({ 
                padding: "20px 10px 50px", 
                boxShadow: "none", 
                background: theme.palette.background.paper, 
                position: "relative",
                borderBottom: `3px solid transparent`,
                transition: "all .1s",

                "&:hover": {
                    borderBottom: `3px solid ${theme.palette.primary.main}`,
                }
            })}
        >
            <CardContent>
                <Typography fontWeight={"bold"}>{title}</Typography>
                <Typography sx={{ m: "15px 0"}} color="text.secondary">
                    {description}
                </Typography>
            </CardContent>
            <CardActions sx={{justifyContent: "space-between", position: "absolute", bottom: "20px", padding: "0 10px", width: "calc(100% - 20px)"}}>
                <Button size="small" onClick={() => navigate(`/blog/${slug}`)}>{t("Learn More")}</Button>
                <Typography variant="caption">{new Date().toLocaleDateString()}</Typography>
            </CardActions>
        </Card>
    )
}

export default PostCard