import { Box } from "@mui/material"
import { FC, useState, useMemo } from "react"
import PostCard from "./post-card";
import { methods } from "@/api/methods";
import { useQuery } from "@tanstack/react-query";

const PostsList: FC<{count?: number, search?: string, grid?: boolean}> = ({count = 100, search, grid = false}) => {
    const {data: posts} = useQuery({
        queryKey: ["blog posts"], 
        queryFn: async () => {
            const {data} = await methods.blog.getPosts();
            return data
        },
    })

    const filter = (post) => {
        if (!search) return true
        return post.title.toLowerCase().includes(search?.toLowerCase())
    }

    const sortByNewest = (a, b) => {
        return new Date(b.created).getTime() - new Date(a.created).getTime()
    }

    const sortedPosts = useMemo(() => posts?.sort(sortByNewest), [posts, search])

    return (
        <Box className={`posts_list ${grid ? "grid" : "wrap"}`}>
            {sortedPosts?.map((post, index) => filter(post) && index < count && <PostCard key={post.slug} {...post} />)}
        </Box>
    )
}

export default PostsList