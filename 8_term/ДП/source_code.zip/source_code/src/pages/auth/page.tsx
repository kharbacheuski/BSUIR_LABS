import React, { useContext, useState } from "react";
import { 
    Box, 
    FormControl, 
    InputLabel, 
    InputAdornment, 
    TextField, 
    OutlinedInput,
    IconButton, 
    Button,
    Typography,
    Link,
    Container,
    FormHelperText,
    ClickAwayListener
} from "@mui/material"
import { AccountCircle, Visibility, VisibilityOff } from '@mui/icons-material';
import { methods } from "@/api/methods";
import Loader from "@/components/Loader";
import AlertComponent from "@/components/AlertComponent";
import { AlertStateType } from "@/components/AlertComponent";
import * as Router from "react-router-dom";
import { AuthContext } from "@/components/providers/auth-provider";
import { useNavigate } from "react-router-dom";
import {Helmet} from "react-helmet";
import { getAxiosErrorMessage } from "@/utilities/get-axios-error-message";
import { checkIsOnboardingRequired } from "@/utilities/is-onboarding-required";
import { OnboardingStatus } from "@/types/enums";
import { useTranslation } from "react-i18next";
import { validateEmail, validatePassword } from "@/utilities/validation";

export enum AuthComponentType {
    Login = "Login",
    Registration = "Registration"
}

const Login: React.FC<{type: AuthComponentType}> = ({type}) => {
    const {t} = useTranslation()
    const [showPassword, setShowPassword] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false)
    const [error, setError] = useState<AlertStateType>({
        isVisible: false,
        message: "",
        severity: "info"
    })
    const [validationError, setValidationError] = useState<{[key: string]: Validate}>({
        email: {isValid: true, message: ""},
        password: {isValid: true, message: ""}
    })

    const [creds, setCreds] = useState<UserCredentialsType>({
        name: "",
        password: "",
    });

    const { isAuth, setIsAuth } = useContext(AuthContext)

    const navigate = useNavigate()

    const registrationHandle = async (creds: UserCredentialsType) => {
        try {
            setLoading(true)

            await methods.user.registration(creds)
            
            loginHandle(creds);
        }
        catch(e: any) {
            setError({isVisible: true, message:  t(e.response.data.errors.Name[0] || e.response.data.errors.Password[0]), severity: "error"})
        }

        finally {
            setLoading(false)
        }
    }

    const loginHandle = async (creds: UserCredentialsType) => {
        try {
            setLoading(true)

            const {data: token} = await methods.user.login(creds)

            localStorage.setItem("token", token.accessToken)

            const {code: onboardingStatusCode} = await checkIsOnboardingRequired()

            setIsAuth(true)

            if(onboardingStatusCode !== OnboardingStatus.Completed) {
                navigate("/onboarding")
            }
            else {
                navigate("/")
            }
        }
        catch(e: any) {
            const message = getAxiosErrorMessage(e)

            setError({isVisible: true, message: t(message), severity: "error"})
        }
        finally {
            setLoading(false)
        }
    }

    const submit = (event) => {
        event.preventDefault()
        event.stopPropagation()
    
        const formData = new FormData(event.currentTarget)

        const name = formData.get('email') as string
        const password = formData.get('password') as string
        const secondPassword = formData.get('second-password') as string

        if(!validationError.email.isValid) return 
        if(type == AuthComponentType.Registration) {

            const passwordValidate = validatePassword(password, secondPassword)

            setValidationError({...validationError, password: passwordValidate})

            if(!passwordValidate.isValid) return
        }
    
        type == AuthComponentType.Login ? loginHandle({name, password}) : registrationHandle({name, password})
    }

    const onClickAway = () => {
        setValidationError({email: {isValid: true, message: ""}, password: {isValid: true, message: ""}})
    }

    return (
        <Container>
            <Helmet>
                <title>{t("Auth")} {type}</title>
                <meta name="description" content="Login finance system cabinet" />
            </Helmet>
            <Box id="login" sx={{
                height: "calc(100vh - 120px)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            }}>
                <ClickAwayListener onClickAway={onClickAway}>
                    <Box 
                        className="form" 
                        component={"form"} 
                        sx={{
                            display: "flex",
                            flexDirection: "column",
                            gap: "20px",
                            justifyContent: "center",
                            width: "100%",
                            maxWidth: "400px",
                            
                        }}
                        onSubmit={submit}
                    >
                        <Typography variant="h4" sx={{ marginBottom: "20px", textAlign: "center" }}>{t(type)}</Typography>

                        <FormControl fullWidth variant="outlined">
                            <TextField
                                label={t("Email")}
                                InputProps={{
                                startAdornment: (
                                        <InputAdornment position="start">
                                            <AccountCircle />
                                        </InputAdornment>
                                    ),
                                }}
                                error={!validationError.email.isValid}
                                name="email"
                                helperText={t(validationError.email.message)}
                                variant="outlined"
                                onChange={(e) => setValidationError({...validationError, email: validateEmail(e.target.value)})}
                            />
                        </FormControl>

                        <FormControl fullWidth variant="outlined">
                            <InputLabel htmlFor="outlined-adornment-password">{t("Password")}</InputLabel>
                            <OutlinedInput
                                type={showPassword ? 'text' : 'password'}
                                endAdornment={
                                    <InputAdornment position="end">
                                        <IconButton
                                            aria-label="toggle password visibility"
                                            onClick={() => setShowPassword(!showPassword)}
                                            onMouseDown={(e) => e.preventDefault()}
                                            edge="end"
                                        >
                                        {showPassword ? <VisibilityOff /> : <Visibility />}
                                        </IconButton>
                                    </InputAdornment>
                                }
                                name="password"
                                label={t("Password")}

                            />
                        </FormControl>

                        {type == AuthComponentType.Registration && <FormControl fullWidth variant="outlined">
                            <InputLabel htmlFor="outlined-adornment-password">{t("Confirm password")}</InputLabel>
                            <OutlinedInput
                                type={'password'}
                                name="second-password"
                                label={t("Confirm password")}
                                error={!validationError.password.isValid}
                            />
                            {!validationError.password.isValid && <FormHelperText color="error">{t(validationError.password.message)}</FormHelperText>}
                        </FormControl>}

                        <Button 
                            type="submit"
                            variant="contained" 
                            sx={{ width: "100%"}}
                        >
                            {t("Send")}
                        </Button>

                        {type == AuthComponentType.Login 
                        ?
                            <Router.Link style={{textDecoration: "none", textAlign: "center"}} to={"/auth/sign-up"}><Link sx={{
                                textDecoration: "none",

                                "&: hover": {
                                    textDecoration: "underline"
                                }
                            }}>{t("Registration")}</Link></Router.Link>
                        : <Router.Link style={{textDecoration: "none", textAlign: "center"}} to={"/auth/sign-in"}><Link sx={{
                            textDecoration: "none",

                            "&: hover": {
                                textDecoration: "underline"
                            }
                        }}>{t("Login")}</Link></Router.Link>
                        }
                    </Box>
                </ClickAwayListener>
                
                <Loader isLoading={loading} />
                <AlertComponent 
                    isVisible={error.isVisible}
                    message={error.message} 
                    onCloseHandle={() => setError({isVisible: false, message: "", severity: "error"})} 
                    type={error.severity}
                />
            </Box>
        </Container>
    )
}

export default Login