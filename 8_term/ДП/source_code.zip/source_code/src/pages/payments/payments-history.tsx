import { Box, Typography, Button, useTheme } from "@mui/material"
import { methods } from "@/api/methods";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import Loader from "@/components/Loader";
import { useTranslation } from "react-i18next";

const PaymentsHistory: React.FC<WalletType> = ({number, currencyCode}) => {
    const [historyCount, setHistoryCount] = useState<number>(3)

    const theme = useTheme()

    const {data: payments, isLoading} = useQuery({
        queryKey: ["payments history"], 
        queryFn: async () => {
            const {data} = await methods.payment.getPaymentsByWalletNumber(number);

            return data
        },
    })

    const {t} = useTranslation()

    return (
        isLoading ? <Loader isLoading={true} /> : <Box 
        sx={{
            display: "flex", 
            flexDirection: "column", 
            gap: "20px", 
            alignItems: "center",
        }}>
            <Typography sx={{textAlign: "center", width: "max-content"}} variant="h5">{t("Payments history")}</Typography>
            
            <Box sx={{
                display: "flex", 
                flexDirection: "column", 
                gap: "20px", 
                marginBottom: "20px",
                maxHeight: "750px",
                overflow: "auto"
            }}> 
                {!payments?.length && (
                    <Box sx={{
                        padding: "10px 25px",
                        backgroundColor: theme.palette.background.paper,
                        borderRadius: "10px",
                        width: "250px"
                    }}>
                        <Typography sx={{textAlign: "center", width: "max-content", margin: "0 auto"}} >{t("No payments yet")}</Typography>
                    </Box>
                    
                )}
                {payments?.map((payment, index) => index < historyCount && (
                    <Link to={`/statement`} key={new Date(payment.created)?.getTime()} style={{textDecoration: "none", color: "inherit"}}>
                        <Box 
                            sx={{
                                padding: "10px 25px",
                                backgroundColor: theme.palette.background.paper,
                                borderRadius: "10px",
                                width: "250px"
                            }}
                            key={payment.balanceOperationTypeCode}
                        >
                            <Box sx={{
                                display: "flex",
                                justifyContent: "space-between",
                            }}>
                                <Box>
                                    {payment.paymentTypeCode} 
                                    <Typography 
                                        sx={{
                                            marginLeft: "5px",
                                            color: payment.balanceOperationTypeCode == "Credit" ? theme.palette.success.light : theme.palette.error.light, 
                                            display: "inline-block"
                                        }}
                                    >
                                        {payment.balanceOperationTypeCode}
                                    </Typography>
                                </Box>
                                <Typography sx={{fontWeight: "bold"}}>{payment.amount?.toFixed(2)}</Typography> 
                            </Box>
                            
                            <Typography variant="caption" sx={{marginTop: "5px"}}>{new Date(payment.created).toLocaleString()} </Typography> 
                        </Box>
                    </Link>
                ))}
                
                {payments!.length > historyCount && (
                    <Button onClick={() => setHistoryCount(prev => prev + 5)} sx={{width: "max-content", margin: "0 auto"}}>View more</Button>
                )}
            </Box>
        </Box>
    );
};

export default PaymentsHistory