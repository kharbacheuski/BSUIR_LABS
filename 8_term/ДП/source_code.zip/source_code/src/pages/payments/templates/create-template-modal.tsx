import { Box, Typography, Button, TextField,} from "@mui/material"
import ModalWindow from "@/components/ModalWindow";
import { FC, Fragment, useState } from "react";
import ColorSelect, { TEMPLATE_COLORS } from "@/components/color-select";
import { methods } from "@/api/methods";
import { AxiosError } from "axios";
import { getAxiosErrorMessage } from "@/utilities/get-axios-error-message";
import { AlertStateType } from "@/components/AlertComponent";
import { Operation } from "../page";
import { useTranslation } from "react-i18next";

type Props = {
    operation: string,
    refetchTemplates,
    setAlertState: React.Dispatch<React.SetStateAction<AlertStateType>>
    formData: UnionOperationType,
}

const CreateTemplateModal: FC<Props> = ({
    operation, 
    refetchTemplates, 
    setAlertState,
    formData
}) => {
    const [templateName, setTemplateName] = useState<string>("")
    const [templateColor, setTemplateColor] = useState<string>(TEMPLATE_COLORS[0].main)

    const [isCreateTemplateModalOpen, setIsCreateTemplateModalOpen] = useState<boolean>(false)

    const {t} = useTranslation()

    const createTemplate = async () => {
        try {
            await methods.payment.template.create({
                name: templateName,
                paymentTypeCode: operation == Operation.TRANSFER ? "Transfer" : formData.paymentTypeCode || "",
                walletNumber: (formData.walletNumber || formData.walletNumberFrom) as string, 
                amount: formData.amount || 0,
                balanceOperationTypeCode: operation == Operation.DEPOSIT ? "Credit": "Debit",
                color: templateColor
            })

            refetchTemplates()
        }
        catch(e: AxiosError | any) {
            const message = getAxiosErrorMessage(e)

            setAlertState({
                isVisible: true,
                message: message,
                severity: "error"
            })
        }
        finally {
            setIsCreateTemplateModalOpen(false)
        }
    }

    return (<Fragment>
        <Button sx={{width: "250px", marginTop: "20px"}} variant="outlined" onClick={() => setIsCreateTemplateModalOpen(true)}>{t("Create template")}</Button>

        <ModalWindow isVisible={isCreateTemplateModalOpen} handleClose={() => setIsCreateTemplateModalOpen(false)}>
            <Box>
                <Typography align="center" variant="h5">{t("Enter a name for your template and select a color")}</Typography>
                <Typography variant="body2" sx={{ textAlign: "center", maxWidth: "500px", margin: "10px auto 0" }}>{t("The template will save the fields you entered such as")}: <b>{t("wallet number")}</b>, <b>{t("amount")}</b>, <b>{t("payment type")}</b> {t("etc")}.</Typography>
            </Box>

            <Box sx={{ display: "flex", gap: "10px", marginTop: "20px" }}>
                <TextField
                    sx={{
                        maxWidth: "350px",
                        width: "100%"
                    }}
                    label={t("Template name")}
                    type="text"
                    variant="filled"
                    onChange={(e) => setTemplateName(e.target.value)}
                />
                <Button color="secondary" onClick={createTemplate} sx={{ width: "250px" }} variant="contained">{t("Save")}</Button>
            </Box>   

            <ColorSelect value={templateColor} setValue={setTemplateColor} />
        </ModalWindow>
    </Fragment> 
    )
}

export default CreateTemplateModal