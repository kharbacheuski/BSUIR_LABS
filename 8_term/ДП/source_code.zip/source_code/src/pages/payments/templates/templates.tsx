import { methods } from "@/api/methods";
import { Box, SvgIcon, Typography } from "@mui/material"
import { FC, Fragment, useState } from "react";
import CloseIcon from '@mui/icons-material/Close';
import { Operation } from "../page";
import { getContrastColor } from "@/components/color-select";
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Scrollbar } from 'swiper/modules';
import 'swiper/scss';
import 'swiper/scss/navigation';
import 'swiper/scss/scrollbar';
import { useQuery } from "@tanstack/react-query";
import CreateTemplateModal from "./create-template-modal";
import AlertComponent, { AlertStateType } from "@/components/AlertComponent";
import { useTranslation } from "react-i18next";

const TemplateCard: FC<{
    data: TemplateType, 
    refetchTemplates: () => void,
    setFormData: React.Dispatch<React.SetStateAction<UnionOperationType>>
    setOperation: React.Dispatch<React.SetStateAction<Operation>>
}> = ({data, refetchTemplates, setFormData, setOperation}) => {
    const handleDelete = async (name) => {
        await methods.payment.template.delete({name})
        refetchTemplates()
    }

    const handleClick = () => {
        if(data.paymentTypeCode == "Transfer") {
            setFormData({
                amount: data.amount,
                walletNumberFrom: data.walletNumber,
                walletNumberTo: "",
            })
            setOperation(Operation.TRANSFER)
        }
        else {
            setFormData({
                amount: data.amount,
                paymentTypeCode: data.paymentTypeCode,
                walletNumber: data.walletNumber,
            })
            setOperation(data.balanceOperationTypeCode == "Debit" ? Operation.WITHDRAW : Operation.DEPOSIT)
        }
    }

    return (
        <Box sx={(theme) => ({
            padding: "10px 40px 10px 20px", 
            borderRadius: "5px",
            backgroundColor: data.color,
            color: getContrastColor(data.color),
            cursor: "pointer",
        })} onClick={handleClick}>
            <Typography sx={{fontWeight: "bold", marginBottom: "7px"}}>{data.name}</Typography>
            <Typography>{data.walletNumber}</Typography>
            <SvgIcon 
                component={CloseIcon} 
                sx={{
                    width: "20px", 
                    height: "20px", 
                    cursor: "pointer",
                    position: "absolute",
                    top: "10px",
                    right: "10px",
                }}
                onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation()
                    handleDelete(data.name)
                }}
            />
        </Box>
    )
}

const TemplatesList: FC<{
    setFormData: React.Dispatch<React.SetStateAction<UnionOperationType>>
    setOperation: React.Dispatch<React.SetStateAction<Operation>>
    operation: Operation,
    formData: UnionOperationType
}> = ({setFormData, setOperation, operation, formData}) => {
    const {data: templates, refetch: refetchTemplates } = useQuery({
        queryKey: ['get-templates'], 
        queryFn: async () => {
            const {data} = await methods.payment.template.get()
            return data
        },
    })

    const [alertState, setAlertState] = useState<AlertStateType>({
        isVisible: false,
        message: "",
        severity: "success",
    })

    const {t} = useTranslation()
        
    return <Fragment>
        {Boolean(templates?.length) && 
        <Box 
            sx={(theme) => ({
                maxWidth: "650px", 
                padding: "20px", 
                borderRadius: "5px", 
                backgroundColor: theme.palette.header,
            })}
        >
            <Swiper
                style={{padding: "10px 0"}}
                spaceBetween={20}
                slidesPerView={3}
                modules={[Navigation, Scrollbar]}
                scrollbar={{ draggable: true }}
                navigation
                breakpoints={{
                    0: {
                        slidesPerView: 2
                    },
                    576: {
                        slidesPerView: 3
                    },
                }}
            >
                {templates?.map(template => (
                    <SwiperSlide key={template.name}>
                        <TemplateCard 
                            key={template.name} 
                            setOperation={setOperation} 
                            setFormData={setFormData} 
                            refetchTemplates={refetchTemplates} 
                            data={template} 
                        />
                    </SwiperSlide>
                ))}
            </Swiper>
            <Typography variant="body2" sx={{marginTop: "6px", fontStyle: "italic"}}>{t("you can use one of these templates")}</Typography>
        </Box>}

        <AlertComponent 
            isVisible={alertState.isVisible} 
            message={alertState.message} 
            type={alertState.severity} 
            onCloseHandle={() => setAlertState({isVisible: false, message: "", severity: "error"})} 
        />

        <CreateTemplateModal 
            refetchTemplates={refetchTemplates}
            operation={operation}
            formData={formData}
            setAlertState={setAlertState}
        />
    </Fragment>
};

export default TemplatesList