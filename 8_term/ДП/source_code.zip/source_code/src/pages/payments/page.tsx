import { Box, Container, Theme, useMediaQuery } from "@mui/material"
import { Fragment, useState } from "react";
import Loader from "@/components/Loader";
import PaymentOperation from "./payment-operation";
import PaymentsHistory from "./payments-history";
import { useParams, useSearchParams } from "react-router-dom";
import CurrencyRates from "@/components/CurrencyRates";
import WalletNotExist from "../wallet/wallet-not-exist-message";
import {Helmet} from "react-helmet";
import { checkIsWalletExist } from "@/utilities/is-wallet-exist";
import TemplatesList from "./templates/templates";
import { useTranslation } from "react-i18next";

export enum Operation {
    DEPOSIT = "deposit",
    WITHDRAW = "withdraw",
    TRANSFER = "transfer",
}

const Payments = () => {
    const {walletNumber} = useParams();

    const {isWalletExist, isLoading} = checkIsWalletExist(walletNumber as string || "")
    
    const [formData, setFormData] = useState<UnionOperationType>({
        walletNumber: walletNumber,
        paymentTypeCode: ""
    })

    const [searchParams,] = useSearchParams();

    const [operation, setOperation] = useState<Operation>(searchParams.get("operation") as Operation || Operation.DEPOSIT)
    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'));

    const {t} = useTranslation()

    return <Fragment>
        <Helmet>
            <title>{t("Payments")}</title>
            <meta name="description" content="Make deposits, withdrawals and transfers to any account wallet"></meta>
        </Helmet>
        
        {walletNumber == undefined || isWalletExist ? 
            <Container className="container">
                <Box sx={{
                    display: "flex", 
                    justifyContent: "space-between", 
                    marginTop: "100px",

                    "@media (max-width: 767px)": {
                        flexDirection: "column",
                        gap: "50px",
                    }
                }}>
                    <Box>
                        <TemplatesList 
                            setFormData={setFormData} 
                            formData={formData} 
                            setOperation={setOperation}
                            operation={operation} 
                        />

                        <PaymentOperation 
                            operation={operation} 
                            setOperation={setOperation} 
                            formData={formData} 
                            setFormData={setFormData}
                        />

                        <Box sx={{display: "flex", zIndex: 1, gap: mdUp ? "20px" : "10px", flexWrap: "wrap", margin: "100px 0 50px"}}>
                            <CurrencyRates />
                        </Box>
                    </Box>
                    
                    {walletNumber && <PaymentsHistory number={walletNumber} />}         
                </Box>
            </Container>
        : <WalletNotExist />}
        
        <Loader isLoading={isLoading} />
    </Fragment>
};

export default Payments