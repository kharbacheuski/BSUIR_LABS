import { methods } from "@/api/methods";
import { useQuery } from "@tanstack/react-query";
import { FC } from "react";
import { 
    FormControl, 
    InputLabel,
    Select, 
    MenuItem,
    SelectProps,
} from "@mui/material"

const PaymentTypeSelect: FC<SelectProps & {
    value: string,
    setValue: (wallet: string) => void,
    helperText?: string
}> = ({value, setValue, helperText, ...props}) => {
    const {data: paymentTypes} = useQuery({
        queryKey: ["payment-types"], 
        queryFn: async () => {
            const {data} = await methods.payment.paymentType()

            return data
        },
    })
    const handleChange = (e) => {
        setValue(e.target.value);
    };

    return (
        <FormControl fullWidth sx={{
            maxWidth: "350px",
            width: "100%"
        }}>
            <InputLabel id="demo-simple-select-label">{props.label}</InputLabel>
            <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={value}
                onChange={handleChange}
                {...props}
            >
                {paymentTypes?.map(paymentType => <MenuItem value={paymentType.code} key={paymentType.code}>{paymentType.code}</MenuItem>)}
            </Select>
        </FormControl>
    );
} 

export default PaymentTypeSelect