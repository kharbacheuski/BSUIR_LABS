import { TextField, FormControl, InputLabel, Button, InputAdornment, Input } from "@mui/material"
import React, { Fragment, useState } from "react";
import { methods } from "@/api/methods";
import { AxiosError } from "axios";
import { getAxiosErrorMessage } from "@/utilities/get-axios-error-message";
import AlertComponent, { AlertStateType } from "@/components/AlertComponent";
import { Operation } from "./page";
import Loader from "@/components/Loader";
import WalletSelect from "../wallet/wallet-select";
import PaymentTypeSelect from "./payment-type-select";
import { useTranslation } from "react-i18next";

export const currencySymbols = {
    USD: "$",
    EUR: "€",
    RUB: "₽",
    BYN: "Br"
}

const getDetailValue = (details: KeyValue[], key: string) => {
    return details.find(detail => detail.key == key)?.value || ""
}

const setDetailValue = (details: KeyValue[], key: string, value: string) => {
    if(details.find(detail => detail.key == key)) {
        return details.map(detail => {
            if(detail.key == key) {
                detail.value = value
            }

            return detail
        })
    }

    return [...details, {key, value}]
}

const PaymentForm: React.FC<{
    formData: UnionOperationType, 
    setFormData: React.Dispatch<React.SetStateAction<UnionOperationType>>
    operation: Operation,
}> = ({operation, formData, setFormData}) => {
    const {t} = useTranslation()

    const [loading, setLoading] = useState<boolean>(false)

    const [alertState, setAlertState] = useState<AlertStateType>({
        isVisible: false,
        message: "",
        severity: "success",
    })

    const [currentCurrency, setCurrentCurrency] = useState("USD")

    const operationAction = async () => {
        try {
            setLoading(true)
            switch(operation) {
                case Operation.DEPOSIT: {
                    const {data} = await methods.payment.deposit(formData as OperationDataType);

                    window.location.replace(data.paymentUrl)
                }; break;
                case Operation.WITHDRAW: {
                    await methods.payment.withdraw(formData as OperationDataType);
                }; break;
                case Operation.TRANSFER: { 
                    await methods.payment.transfer(formData as TransferDataType);
                }; break
                default: {
                    console.error("Unknown operation type")
                }
            }
            setAlertState({
                isVisible: true,
                message: t("Transaction succeeded"),
                severity: "success"
            })
        }
        catch(e: AxiosError | any) {
            const message = getAxiosErrorMessage(e)

            setAlertState({
                isVisible: true,
                message: message,
                severity: "error"
            })
        }
        finally {
            setLoading(false)
        }
    }

    const handleChangeWalletNumber = (value: WalletType, key: "walletNumber" | "walletNumberFrom") => {
        setFormData(prev => ({...prev, [key]: String(value.number)}))
        setCurrentCurrency(value?.currencyCode || "USD")
    }

    return (<Fragment>
            <FormControl sx={{
                display: "flex", 
                flexDirection: "column", 
                gap: "30px", 

                "@media (max-width: 767px)": {
                    alignItems: "center", 
                }
            }}>
                {operation == Operation.TRANSFER ? 
                    <Fragment>
                        <WalletSelect 
                            value={formData.walletNumberFrom || ""}
                            setValue={(value) => {
                                handleChangeWalletNumber(value as WalletType, "walletNumberFrom")
                            }}
                            label={t("Wallet number from")}
                        />

                        <WalletSelect 
                            anyWallet={true}
                            value={formData.walletNumberTo || ""}
                            setValue={(value) => {
                                setFormData(prev => ({...prev, walletNumberTo: String(value)}))
                            }}
                            label={t("Wallet number to")}
                        />
                    </Fragment>

                :    <Fragment>
                        <PaymentTypeSelect
                            value={formData.paymentTypeCode || ""}
                            setValue={(value) => {
                                setFormData(prev => ({...prev, paymentTypeCode: value}))
                            }}
                            label={t("Payment Type")}
                        />

                        <WalletSelect 
                            value={formData.walletNumber || ""}
                            setValue={(value) => {
                                handleChangeWalletNumber(value as WalletType, "walletNumber")
                            }}
                            label={t("Wallet number")}
                        />
                    </Fragment>
                }

                {operation == Operation.WITHDRAW && 
                    <TextField
                        sx={{
                            maxWidth: "350px",
                            width: "100%"
                        }}
                        label={t("Bank Account Number")}
                        variant="standard"
                        value={getDetailValue(formData.details || [], "bankAccountNumber")}
                        onChange={(e) => setFormData(prev => ({...prev, details: setDetailValue(prev.details || [], "bankAccountNumber", e.target.value)}))}
                    />
                }

                <FormControl                    
                    sx={{maxWidth: "350px", width: "100%"}} 
                    variant="standard"
                >
                    <InputLabel>{t("Amount")}</InputLabel>
                    <Input
                        type="number"
                        value={formData.amount}
                        onChange={(e) => setFormData(prev => ({...prev, amount: Number(e.target.value)}))}
                        startAdornment={<InputAdornment position="start">{currencySymbols[currentCurrency]}</InputAdornment>}
                    />
                </FormControl>

                
                <Button 
                    onClick={operationAction}
                    sx={{
                        marginTop: "30px",
                        width: "250px"
                    }}
                    variant="contained"
                >
                    {t(operation)}
                </Button> 
            </FormControl>

            <Loader isLoading={loading} />
            
            <AlertComponent 
                isVisible={alertState.isVisible} 
                message={alertState.message} 
                type={alertState.severity} 
                onCloseHandle={() => setAlertState({isVisible: false, message: "", severity: "error"})} 
            />
        </Fragment>
    )
}

export default PaymentForm