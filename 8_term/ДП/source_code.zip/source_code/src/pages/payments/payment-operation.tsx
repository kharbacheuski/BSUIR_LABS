import { Box, Tabs, Tab, useMediaQuery, Theme, useTheme} from "@mui/material"
import React, { FC } from "react";
import PaymentForm from "./payment-form";
import {Circle} from "../../../images/icons"
import { Operation } from "./page";
import { useTranslation } from "react-i18next";
import { useSearchParams } from "react-router-dom";

const PaymentOperation: FC<{
    formData: UnionOperationType,
    setFormData: React.Dispatch<React.SetStateAction<UnionOperationType>>
    operation: Operation,
    setOperation: React.Dispatch<React.SetStateAction<Operation>>
}> = ({formData, setFormData, operation, setOperation}) => {
    const theme = useTheme();

    const [, setSearchParams] = useSearchParams();

    const mdUp = useMediaQuery((theme: Theme) => theme.breakpoints.down(767));

    const handleTabChange = (event: React.SyntheticEvent, newValue: Operation) => {
        setOperation(newValue);
        setSearchParams({operation: newValue})
    }

    const {t} = useTranslation()

    return (
        <Box sx={{marginTop: "20px"}}>
            <Tabs sx={{
                overflow: "auto"
            }} variant={mdUp ? "fullWidth" : "standard"} value={operation} onChange={handleTabChange}>
                <Tab label={t("Deposit")} value={Operation.DEPOSIT}/>
                <Tab label={t("Withdraw")} value={Operation.WITHDRAW}/>
                <Tab label={t("Transfer")} value={Operation.TRANSFER}/>
            </Tabs>

            <Box sx={{display: "flex", flexDirection: "column", gap: "20px", margin: "40px 0 0 0"}}>
                <PaymentForm
                    formData={formData} 
                    setFormData={setFormData}
                    operation={operation}
                />
            </Box>

            <Box sx={{
                position: "absolute",
                bottom: "-200px",
                left: "-200px",
                zIndex: -1
            }}>
                <Circle width={500} height={500} color={theme.palette.mode === "dark" ? "#282533": "#E3DCFF"}/>
            </Box>

            <Box sx={{
                position: "absolute",
                top: "-100px",
                right: "200px",
                zIndex: -1
            }}>
                <Circle width={250} height={250} color="#7756FE"/>
            </Box>
        </Box>
    );
};

export default PaymentOperation