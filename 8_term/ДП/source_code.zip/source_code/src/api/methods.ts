import { OnboardingStatus } from "@/types/enums";
import { checkIsOnboardingRequired } from "@/utilities/is-onboarding-required";
import axios, { AxiosError } from "axios";

const api = axios.create({
    baseURL: process.env.REACT_APP_BASE_API_URL,
    headers: {
        ['Content-Type']: "application/json; charset=utf8",
        ['Access-Control-Allow-Origin']: "*"
    }
});

api.interceptors.request.use(
    config => {
        config.headers['Authorization'] = `Bearer ${localStorage.getItem("token")}`    

        return config;
    }
)

api.interceptors.response.use(response => {
    return response;
  }, async function (error: AxiosError) {
    if (error.response?.status === 401) {
        localStorage.removeItem("token")
        window.location.href = '/auth/sign-in'
    }
    if (error.response?.status === 403) {
        if(error.response.data === "Access denied: onboarding is required.") {
            const {code: onboardingStatusCode} = await checkIsOnboardingRequired()

            if(onboardingStatusCode !== OnboardingStatus.Completed)
                window.location.href = '/onboarding'
        }
    }

    return Promise.reject(error);
});

export const methods = {
    user: {
        login(data: UserCredentialsType) {
            return api.post<TokenType>(`/user/auth/`, data)
        },
        registration(data: UserCredentialsType) {
            return api.post<TokenType>(`/user/`, data)
        },
        loginActivity() {
            return api.get<LoginActivityType[]>(`/user/login/activity`)
        },
        getAvatar() {
            return api.get(`/user/profile/avatar`, {responseType: 'arraybuffer'}).then(res => {
                let image = btoa(
                    new Uint8Array(res.data)
                        .reduce((data, byte) => data + String.fromCharCode(byte), '')
                );

                return `data:${res.headers['content-type'].toLowerCase()};base64,${image}`;
            })
        },
        setAvatar(formData: FormData) {
            return api.post(`/user/profile/avatar`, formData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                    "x-rapidapi-host": "file-upload8.p.rapidapi.com",
                    "x-rapidapi-key": "your-rapidapi-key-here",
                },
            })
        },
        changePassword(data: Password) {
            return api.put(`/user/password/`, data)
        },
        deleteAccount() {
            return api.delete(`/user/`)
        },
        verification(params: {secret: string}) {
            return api.get(`/user/verification/`, {params})
        }
    },
    wallet: {
        create(data: CurrencyType) {
            return api.post<WalletType>(`/wallet/`, data)
        },
        getWallets() {
            return api.get<WalletType[]>(`/wallet/`)
        },
        getWalletByNumber(walletNumber: string) {
            return api.get<WalletType[]>(`/wallet/${walletNumber}`)
        },
        getWalletBalance(walletNumber: string) {
            return api.get<WalletBalance>(`/wallet/balance/`, {params: {number: walletNumber}})
        },
        delete(walletNumber: string) {
            return api.delete(`/wallet/`, {data: {number: walletNumber}})
        }
    },
    payment: {
        getPaymentsByWalletNumber(walletNumber?: string) {
            return api.get<PaymentRecordType[]>(`/payment/${walletNumber || ""}`)
        },
        withdraw(data: OperationDataType) {
            return api.post(`/payment/withdraw`, data)
        },
        deposit(data: OperationDataType) {
            return api.post<PaymentUrlType>(`/payment/deposit`, data)
        },
        transfer(data: TransferDataType) {
            return api.post<PaymentUrlType>(`/payment/transfer`, data)
        },
        paymentType() {
            return api.get<PaymentType[]>(`/payment/type`)
        },

        template: {
            get() {
                return api.get<TemplateType[]>(`/payment/template/`)
            },
            create(data: CreateTemplateParams) {
                return api.post<TemplateType>(`/payment/template/`, data)
            },
            delete(data: DeleteTemplateParams) {
                return api.delete(`/payment/template/`, {data})
            }
        }
    },
    currency: {
        getCurrencies() {
            return api.get<Currency[]>(`/currency/`)
        },
        getRates(params?: GetCurrencyRateParams) {
            return api.get<CurrencyRate[]>(`/currency/rate/`, {params})
        }
    },
    blog: {
        getPosts(params?: GetPostsParams) {
            return api.get<PostType[]>(`/blog/post/`, {params})
        },
        getSinglePost(slug: string) {
            return api.get<PostType>(`/blog/post/single/`, {params: {slug}})
        }
    },
    contact: {
        getTypes() {
            return api.get<ContactType[]>(`/contact/type/`)
        },
        getContacts() {
            return api.get<Contact[]>(`/contact/`)
        },
        createContact(data: Contact) {
            return api.post<Contact>(`/contact/`, data)
        },
        deleteContact(data: {value: string}) {
            return api.delete(`/contact/`, {data})
        }
    },
    onboarding: {
        getQuestions(params?: OnboardingQuestionParams) {
            return api.get<OnboardingQuestion[]>(`/onboarding/question/`, {params})
        },
        getQuestionnaire() {
            return api.get<OnboardingQuestionnaire[]>(`/onboarding/questionnaire/`)
        },
        answer(data: OnboardingAnswer[]) {
            return api.post(`/onboarding/answer/`, data)
        },
        status(params) {
            return api.get<{code: string}>(`/onboarding/status/`, {params})
        }
    }
}
