declare module '*.png';
declare module '*.jpg';
declare module '*.ttf';
declare module '*.woff';
declare module '*.woff2';
declare module '*.svg';
declare module '*.gif';