import { methods } from "@/api/methods";
import { OnboardingStatus } from "@/types/enums";
import { jwtDecode } from "jwt-decode";

export const checkIsOnboardingRequired = async () => {
    const onboardingStatus = {
        code: OnboardingStatus.Required as string
    }

    try {
        const token = localStorage.getItem("token") || ""
        const decodedToken = jwtDecode(token) as any

        const {data} = await methods.onboarding.status({username: decodedToken.name})

        onboardingStatus.code = data.code
    }
    catch(e) {
        console.error(e)    
    }

    return onboardingStatus
}