import { Shadows, createTheme } from '@mui/material/styles';

export const theme = (isThemeDark) => createTheme({
    palette: {
        header: isThemeDark ? "#15141a75" : "#502fe50d",
        mode: isThemeDark ? "dark": "light",
        primary: {
            main: '#6948ff',
            light: '#fff',
            dark: '#4f2ee4',
        },
        secondary: {
            main: isThemeDark ? '#201f1f' : '#080808',
        },
        background: {
            default: isThemeDark ? "#0d0d0d" : "#fff",
            paper: isThemeDark ? "#131313" : "#F6F4FE",
        },
    },
    components: {
        MuiContainer: {
            styleOverrides: {
                root: {
                    paddingLeft: "20px",
                    paddingRight: "20px"
                }
            },
            defaultProps: {
                disableGutters: true
            }
        }
    },
    typography: {
        "fontFamily": `"Helvetica Neue", sans-serif`,
        "fontSize": 14,                
        "fontWeightLight": 300,
        "fontWeightRegular": 400,
        "fontWeightMedium": 500
    }
});