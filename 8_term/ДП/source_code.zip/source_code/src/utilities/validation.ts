export const validateEmail = (email: string): Validate => {
    const valid = /^.*@.*$/.test(email)
    return {
        isValid: valid,
        message: valid ? "" : "Invalid email"
    }
}

export const validatePassword = (password: string, secondPassword: string): Validate => {
    const valid = password === secondPassword
    return {
        isValid: valid,
        message: valid ? "" : "Passwords do not match"
    }
}