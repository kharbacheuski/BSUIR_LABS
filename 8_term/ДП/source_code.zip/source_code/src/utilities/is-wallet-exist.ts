import { methods } from "@/api/methods";
import { useQuery } from "@tanstack/react-query";

export const checkIsWalletExist = (walletNumber: string): {isLoading: boolean, isWalletExist: boolean} => {
    if(!walletNumber) {
        return {
            isLoading: false,
            isWalletExist: false
        }
    }

    const {data: wallets, isLoading} = useQuery({
        queryKey: ["is wallet exist"], 
        queryFn: async () => {
            const {data} = await methods.wallet.getWallets();
            return data
        },
    })

    const isWalletExist = wallets?.find(wallet => wallet.number === walletNumber) !== undefined

    return {isLoading, isWalletExist}
}