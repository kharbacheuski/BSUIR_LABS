import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import resources from '../localization';

const localizationInstance = i18n.createInstance();

localizationInstance.use(initReactI18next).init({
    resources,
    lng: 'en', 
    fallbackLng: 'en',
    interpolation: { escapeValue: false },
    react: { useSuspense: true },
});

export default localizationInstance;