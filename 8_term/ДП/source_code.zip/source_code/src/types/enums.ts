export enum OnboardingStatus {
    Required = "required",
    Completed = "completed"
}