type UserCredentialsType = {
    name: string,
    password: string,
    roleCode?: string
}

type TokenType = {
    accessToken: string,
    expirationDate: string
}

type CurrencyType = {
    currencyCode: string
}

type Currency = {
    code: string
}

type WalletType = {
    number: string,
    currencyCode?: string
}

type PaymentRecordType = {
    id?: string,
    walletNumber: string,
    balanceOperationTypeCode: string,
    amount: number,
    paymentTypeCode: string,
    paymentStatusCode: string,
    created: Date
}

type PaymentUrlType = {
    paymentUrl: string
}

type KeyValue = {
    key: string,
    value: string
}

type OperationDataType = {
    paymentTypeCode: string,
    walletNumber: string,
    amount: number,
    details: KeyValue[],
}

type TransferDataType = {
    walletNumberFrom: string,
    walletNumberTo: string,
    amount: number
}

type UnionOperationType = Partial<OperationDataType & TransferDataType>

type PaymentType = {
    code: string
}

type WalletNumber = {
    number: string
}

type WalletBalance = {
    currencyCode: string,
    value: number
}

type LoginActivityType = {
    type: string,
    loginDate: string,
    device: string,
    browser: string,
    ipAddress: string
}

type Password = {
    password: string
}

type CurrencyRate = {
    currencyFromCode: string
    currencyToCode: string,
    rate: number,
    date: Date
}

type GetCurrencyRateParams = Pick<CurrencyRate, "currencyFromCode" | "currencyToCode">

type PostType = {
    title: string,
    description?: string,
    content?: string
    slug: string,
    created: string
    imageUrl?: string
}

type GetPostsParams = {
    pageSize: number,
    pageNumber: number
}

type ContactType = {
    code: string
}

type Contact = {
    contactType: string,
    value: string,
}

type TemplateType = {
  name: string
  color: string
  walletNumber: string
  paymentTypeCode: string
  balanceOperationTypeCode: "Credit" | "Debit"
  amount: number
  created: string
}

type DeleteTemplateParams = Pick<TemplateType, "name">
type CreateTemplateParams = Omit<TemplateType, "created">

enum OnboardingAnswerType {
    MULTI = "multi",
    SINGLE = "single"
}

type OnboardingQuestion = {
    id: string,
    questionnaire: string
    value: string
    order: number,
    answerDatatype: string,
    answerType: OnboardingAnswerType | string
    preparedAnswers: string[]
    customAnswerAllowed: boolean
    isRequired: boolean
    modified: string
    created: string
}

type OnboardingQuestionParams = {
    questionnaire: string
}

type OnboardingAnswer = {
    question: string,
    value: string
}

type OnboardingAnswerMap = {
    [question: string]: string,
}

type OnboardingQuestionnaire = {
    name: string
}

type Language = {
    name: string,
    code: string
}

type Validate = {
    isValid: boolean,
    message: string
}