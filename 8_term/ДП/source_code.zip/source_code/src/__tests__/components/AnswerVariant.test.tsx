import { fireEvent, render, screen } from "@/__tests__/setup";
import AnswerVariants from "@/pages/onboarding/components/AnswerVariants"; // путь к компоненту
const mockData = {
    id: "randomId",
    questionnaire: "",
    value: "",
    order: 3,
    answerType: "single",
    isRequired: true,
    modified: "",
    created: ""
}

describe("AnswerVariants", () => {
    it("должен рендерить Input, если нет preparedAnswers", async () => {
        const mockSetValue = jest.fn();
        const question: OnboardingQuestion = {
            answerDatatype: "text",
            preparedAnswers: [],
            customAnswerAllowed: false,
            ...mockData
        };
        
        const value = "";

        await render(<AnswerVariants question={question} value={value} setValue={mockSetValue} />);

        const input = screen.getByPlaceholderText("Type your answer");
        expect(input).toBeInTheDocument();
        expect(input).toHaveAttribute("type", "text");
    });

    it("должен рендерить RadioGroup, если есть preparedAnswers", () => {
        const mockSetValue = jest.fn();
        const question: OnboardingQuestion = {
            answerDatatype: "numeric",
            preparedAnswers: ["Answer 1", "Answer 2"],
            customAnswerAllowed: false,
            ...mockData
        };

        render(<AnswerVariants question={question} value={"Answer 1"} setValue={mockSetValue} />);

        const radioButtons = screen.getAllByRole("radio");
        expect(radioButtons).toHaveLength(2);
        expect(screen.getByLabelText("Answer 1")).toBeInTheDocument();
        expect(screen.getByLabelText("Answer 2")).toBeInTheDocument();
    });

    it("должен обновить значение при изменении input", () => {
        const mockSetValue = jest.fn();
        const question: OnboardingQuestion = {
            answerDatatype: "text",
            preparedAnswers: [],
            customAnswerAllowed: false,
            ...mockData
        };

        render(<AnswerVariants question={question} value={"Old value"} setValue={mockSetValue} />);

        const input = screen.getByPlaceholderText("Type your answer");

        fireEvent.change(input, { target: { value: "New value" } });

        expect(mockSetValue).toHaveBeenCalledWith("New value");
    });

    it("должен показывать Input для кастомного ответа, если customAnswerAllowed true", () => {
        const mockSetValue = jest.fn();
        const question: OnboardingQuestion = {
            answerDatatype: "numeric",
            preparedAnswers: ["Answer 1", "Answer 2"],
            customAnswerAllowed: true,
            ...mockData
        };

        render(<AnswerVariants question={question} value={""} setValue={mockSetValue} />);

        const customInput = screen.getByPlaceholderText("Type other answer");
        expect(customInput).toBeInTheDocument();
        expect(customInput).toHaveAttribute("type", "number");
    });

    it("должен вызывать setValue при выборе радиокнопки", () => {
        const mockSetValue = jest.fn();
        const question: OnboardingQuestion = {
            answerDatatype: "text",
            preparedAnswers: ["Answer 1", "Answer 2"],
            customAnswerAllowed: false,
            ...mockData
        };

        render(<AnswerVariants question={question} value={""} setValue={mockSetValue} />);

        const radio1 = screen.getByLabelText("Answer 1");
        fireEvent.click(radio1);

        expect(mockSetValue).toHaveBeenCalledWith("Answer 1");
    });
});
