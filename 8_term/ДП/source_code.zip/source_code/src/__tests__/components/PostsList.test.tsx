import { methods } from '@/api/methods';
import { render, screen, waitFor } from '../setup'
import PostsList from '@/pages/post/posts-list';

jest.mock('@/api/methods', () => ({
    methods: {
        blog: {
            getPosts: jest.fn().mockReturnValue(Promise.resolve({ 
                data: [
                    { slug: 'post-1', title: 'Post Crypto 1', created: '2025-03-10T12:00:00Z' },
                    { slug: 'post-2', title: 'Post Crypto 2', created: '2025-03-09T12:00:00Z' },
                    { slug: 'post-3', title: 'Post Cars 3', created: '2025-03-08T12:00:00Z' },
                ],
            })),
        },
    },
}));

describe('PostsList', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('renders posts correctly', async () => {
        render(<PostsList count={2} />);

        await waitFor(() => screen.getByText('Post Crypto 1'));

        expect(screen.getByText('Post Crypto 1')).toBeInTheDocument();
        expect(screen.getByText('Post Crypto 2')).toBeInTheDocument();
        expect(screen.queryByText('Post Cars 3')).not.toBeInTheDocument();
    });

    it('filters posts based on search term', async () => {
        render(<PostsList search="Crypto" />);

        await waitFor(() => screen.getByText('Post Crypto 1'));
        expect(screen.getByText('Post Crypto 1')).toBeInTheDocument();
        expect(screen.queryByText('Post Cars 3')).not.toBeInTheDocument();
    });

    it('sorts posts by created date', async () => {
        render(<PostsList count={2} />);

        await waitFor(() => screen.getByText('Post Crypto 1'));

        const posts = screen.getAllByText(/Post/);
        expect(posts[0]).toHaveTextContent('Post Crypto 1');
        expect(posts[1]).toHaveTextContent('Post Crypto 2');
    });

    it('calls the getPosts API method on render', async () => {
        render(<PostsList count={2} />);

        await waitFor(() => expect(methods.blog.getPosts).toHaveBeenCalledTimes(1));
    });
});
