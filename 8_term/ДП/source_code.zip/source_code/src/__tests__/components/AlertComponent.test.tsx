import { fireEvent, render, screen, waitFor } from "@/__tests__/setup";
import AlertComponent, { AlertStateType } from "@/components/AlertComponent";

test("Alert рендерится корректно", async () => {
    let state: AlertStateType = {
        isVisible: true,
        message: "Test message",
        severity: "info"
    }

    const setState = (newState) => {
        state = {...newState}
    };

    render(<AlertComponent 
        isVisible={state.isVisible} 
        message={state.message} 
        type={state.severity} 
        onCloseHandle={() => setState({isVisible: false, message: "", severity: "error"})} 
    />);
    const closeButton = screen.getByRole("close-alert");
    expect(closeButton).toBeInTheDocument();

    fireEvent.click(closeButton);

    await waitFor(() => {
        expect(state.isVisible).toBe(false)
        expect(state.message).toBe("")
    });  
});