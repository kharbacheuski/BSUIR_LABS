import { methods } from '@/api/methods';
import { render, screen, fireEvent, cleanup, waitFor, within  } from '../setup';
import WalletSelect from '@/pages/wallet/wallet-select';

jest.mock('@/api/methods', () => ({
    methods: {
        wallet: {
            getWallets: jest.fn().mockReturnValue(Promise.resolve({ 
                data: [
                    { number: 'KQC240sYC', currencyCode: 'USD' },
                    { number: 'NLO981WzO', currencyCode: 'EUR' },
                ] 
            })),
            getWalletBalance: jest.fn().mockReturnValue(Promise.resolve({ data: { value: 1000 } })),
        },
    },
}));

describe('WalletSelect', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    afterEach(() => {
        cleanup()  
    });

it('displays wallets when available', async () => {
    const {getByRole} = render(<WalletSelect value="" setValue={jest.fn()} label="Select Wallet" />);

    fireEvent.mouseDown(screen.getByRole("button"));
    const listbox = within(getByRole('listbox'));

    await waitFor(() => {
        expect(listbox.getByText("KQC240sYC (USD)")).toBeInTheDocument();
        expect(listbox.getByText("NLO981WzO (EUR)")).toBeInTheDocument();
    });
});

    it('updates the wallet balance when a wallet is selected', async () => {
        render(<WalletSelect value="KQC240sYC" setValue={jest.fn()} label="Select Wallet" />);

        await waitFor(() => {
            expect(screen.getByText("KQC240sYC (USD)")).toBeInTheDocument();
            expect(screen.getByText("Current balance: 1000")).toBeInTheDocument();
        });
    });

    it('calls handleChange when a wallet is selected', async () => {
        const setValueMock = jest.fn();

        const {getByRole} = render(<WalletSelect value="" setValue={setValueMock} label="Select Wallet" />);

        fireEvent.mouseDown(screen.getByRole("button"));

        const listbox = within(getByRole('listbox'));

        fireEvent.click(listbox.getByText("KQC240sYC (USD)"));
        expect(setValueMock).toHaveBeenCalledWith({ number: 'KQC240sYC', currencyCode: 'USD', label: 'KQC240sYC (USD)' });
    });

    it('shows "No wallets" if no wallets are available', async () => {
        (methods.wallet.getWallets as jest.Mock).mockResolvedValueOnce({
            data: [],
            isLoading: false,
        });

        const { getByRole } = render(<WalletSelect value="" setValue={jest.fn()} label="Select Wallet" />);
        fireEvent.mouseDown(screen.getByRole("button"));

        const listbox = within(getByRole('listbox'));

        await waitFor(() => {
            expect(listbox.getByText('No wallets')).toBeInTheDocument();
        });
    });
});
