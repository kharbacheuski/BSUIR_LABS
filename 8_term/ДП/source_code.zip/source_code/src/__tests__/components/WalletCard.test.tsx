import { render, screen } from "@/__tests__/setup";
import WalletCard from "@/pages/wallet/wallet-card";

test("WalletCard рендерится корректно", () => {
    const wallet = {
        number: "1234567890",
        currencyCode: "USD"
    }

    render(<WalletCard wallet={wallet} refetch={jest.fn()} />);
    expect(screen.getByText("1234567890")).toBeInTheDocument();
});