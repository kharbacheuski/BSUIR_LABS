import { fireEvent, render, screen } from "@/__tests__/setup";
import CreateWallet from "@/pages/wallet/create-wallet";

test("CreateWallet рендерится корректно", () => {
    render(<CreateWallet refetch={jest.fn()} />);
    const createButton = screen.getByText(/create/i);
    expect(createButton).toBeInTheDocument();

    fireEvent.click(createButton);

    const input = screen.getByLabelText(/currency/i)
    expect(input).toBeInTheDocument();
    expect(screen.getByText(/cancel/i)).toBeInTheDocument();
});