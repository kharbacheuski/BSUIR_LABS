import { render, screen, waitFor } from '../setup';
import CurrencyRates from '@/components/CurrencyRates';
import { methods } from '@/api/methods';

jest.mock('@/api/methods', () => ({
    methods: {
        currency: {
            getRates: jest.fn().mockReturnValue(Promise.resolve({ 
                data: [
                    { currencyFromCode: 'USD', currencyToCode: 'EUR', rate: 0.85, date: '2024-04-20T12:25:34.62' },
                    { currencyFromCode: 'USD', currencyToCode: 'GBP', rate: 0.75, date: '2024-04-20T12:28:17.62' },
                ],
            })),
        },
    },
}));

describe('CurrencyRates', () => {
    beforeEach(() => {
        // Очищаем моки перед каждым тестом
        jest.clearAllMocks();
    });

    it('renders currency rates when data is fetched', async () => {
        render(<CurrencyRates />);

        await waitFor(() => screen.getByText('USD/EUR'));

        expect(screen.getByText('USD/EUR')).toBeInTheDocument();
        expect(screen.getByText('0.85')).toBeInTheDocument();
        expect(screen.getByText('USD/GBP')).toBeInTheDocument();
        expect(screen.getByText('0.75')).toBeInTheDocument();
        expect(screen.getByText('12:25:34 PM')).toBeInTheDocument();
    });

    it('calls getRates API method on render', async () => {
        render(<CurrencyRates />);

        await waitFor(() => expect(methods.currency.getRates).toHaveBeenCalledTimes(1));
    });
});
