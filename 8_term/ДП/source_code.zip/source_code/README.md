# Finance system platform cabinet

